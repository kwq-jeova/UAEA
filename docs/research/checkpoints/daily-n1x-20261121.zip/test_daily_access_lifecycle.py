import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import study  # Loads the same Harness modules as the daily entry.
from daily_web import WEB_NAMES, DailyWebAdapter, bind_search_scope, web_route
from harness.observation_boundary import CapabilityInputError
from phase2.web_adapter import WebAdapter, WebSearchConstraints


RESUME = "请你继续尝试搜索获得数据，以完成当前分析的工作"


class AccessLifecycleTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.run_dir = Path(temp.name)
        self.text = "/web 请用 Google 搜索指数，只搜索"
        self.policy = {
            "enabled": True,
            "tool_names": ["read_section", "web_search"],
            "input_sha256": hashlib.sha256(self.text.encode()).hexdigest(),
        }
        self.step = {
            "workflow_id": "task",
            "capability": "web.search",
            "execution_observation_id": "observation",
            "action": {
                "harness": {"turn_id": "previous", "input_id": "input", "call_id": "call"},
                "execution_contract": {
                    "allowed": True,
                    "effective_parameters": {"provider": "google", "allow_fallback": False},
                },
                "host_execution_receipt": {
                    "execution_observation": {"observation_id": "observation"},
                    "result": {"tool": "web_search", "data": {"http_attempted": True}},
                },
            },
        }
        self.snapshot = {
            "task_id": "task", "current_input_id": "input", "last_turn_id": "previous",
            "workflow_continuity": {"workflow_id": "task", "attempts": [self.step]},
        }
        self.save()

    def save(self):
        for name, obj in (("input.json", {"text": self.text}),
                          ("after-state.json", {"snapshot": self.snapshot}),
                          ("web-access-policy.json", self.policy)):
            (self.run_dir / name).write_text(json.dumps(obj), encoding="utf-8")

    def test_current_request_for_search_only_uses_previous_public_provider(self):
        route = web_route(RESUME, self.run_dir)
        self.assertEqual(route.names, {"web_search"})
        self.assertEqual(route.first_tool, "web_search")
        self.assertEqual(route.provider, "google")
        schema = {"properties": {"provider": {"enum": ["google", "bing"]},
                                 "allow_fallback": {"type": "boolean"}}, "required": ["query"]}
        request = {"tools": [{"name": "web_search", "parameters": schema}]}
        bind_search_scope(request, route.provider)
        self.assertEqual(schema["properties"]["provider"]["enum"], ["google"])
        self.assertEqual(schema["properties"]["allow_fallback"]["enum"], [False])

    def test_intervening_turn_with_inherited_workflow_attempt_cannot_open_web(self):
        self.snapshot["current_input_id"] = "intervening-input"
        self.snapshot["last_turn_id"] = "intervening-turn"
        self.save()
        self.assertFalse(web_route(RESUME, self.run_dir).names)

    def test_search_disallowed_in_previous_turn(self):
        self.policy["enabled"] = False
        self.policy["tool_names"] = ["read_section"]
        self.save()
        self.assertFalse(web_route(RESUME, self.run_dir).names)

    def test_unexecuted_provider_switch_has_no_public_search(self):
        self.step["action"]["execution_contract"]["allowed"] = False
        self.step["action"]["host_execution_receipt"]["result"]["data"] = {
            "failure_scope": "web.provider_fallback"}
        self.save()
        self.assertFalse(web_route(RESUME, self.run_dir).names)

    def test_evidence_for_different_input_or_observation_cannot_open_web(self):
        self.policy["input_sha256"] = "other"
        self.save()
        self.assertFalse(web_route(RESUME, self.run_dir).names)
        self.policy["input_sha256"] = hashlib.sha256(self.text.encode()).hexdigest()
        self.step["execution_observation_id"] = "other"
        self.save()
        self.assertFalse(web_route(RESUME, self.run_dir).names)

    def test_no_implicit_renewal_on_new_topic_or_reference(self):
        for text in ("用同样的方法分析另一个指数", "接着做", "请解释“继续搜索获得数据”"):
            with self.subTest(text=text):
                self.assertFalse(web_route(text, self.run_dir).names)
        self.assertEqual(web_route("用同样的方法分析另一个指数", self.run_dir,
                                   session_web="current-window").first_tool, "web_search")

    def test_current_action_narrowing_in_command_and_session(self):
        for terminal in (False, True):
            kwargs = {"terminal_web": True} if terminal else {"session_web": "current-window"}
            for text, tools in (("不能搜索，只能打开链接", {"web_fetch"}),
                                ("仅可搜索，不能打开网页", {"web_search"}),
                                ("仅限本地文件", set()), ("这轮不使用网络", set()),
                                ("现有材料够了，不要再上网", set())):
                with self.subTest(terminal=terminal, text=text):
                    route = web_route(text, **kwargs)
                    self.assertEqual(route.names, tools)
                    self.assertIn(route.first_tool, {None, *tools})
        self.assertEqual(web_route("解释“不能搜索，只能打开链接”", session_web="current-window").names,
                         WEB_NAMES)

    def test_negated_provider_cannot_become_positive_selection(self):
        route = web_route("/web 请用 Google 搜索指数，不要用 Bing")
        self.assertEqual(route.provider, "google")
        route = web_route("/web 请用 Bing 搜索指数，禁止用 Bing")
        schema = {"properties": {"provider": {"enum": ["google", "bing", "duckduckgo"]},
                                 "allow_fallback": {"type": "boolean"}}, "required": ["query"]}
        request = {"tools": [{"name": "web_search", "parameters": schema}]}
        bind_search_scope(request, route.provider, excluded_providers=route.excluded_providers)
        self.assertEqual(request["tools"], [])
        self.assertIsNone(route.first_tool)

    def test_exclusions_hold_at_the_wire_and_before_transport(self):
        route = web_route("/web 请检索指数，禁止用 Google 或 Bing")

        self.assertFalse(web_route("请解释'，需要材料你可以从Google站点搜索，'的意思").names)
        self.assertEqual(web_route("/web 不使用 Google，查公开资料").excluded_providers, {"google"})
        self.assertIsNone(route.provider)
        self.assertEqual(route.excluded_providers, {"bing", "google"})
        schema = {"properties": {"provider": {"enum": ["google", "bing", "duckduckgo"]},
                                 "allow_fallback": {"type": "boolean"}}, "required": ["query"]}
        request = {"tools": [{"name": "web_search", "parameters": schema}]}
        bind_search_scope(request, route.provider, excluded_providers=route.excluded_providers)
        self.assertEqual(schema["properties"]["provider"]["enum"], ["duckduckgo"])
        self.assertIn("provider", schema["required"])
        adapter = DailyWebAdapter(snapshot_root=self.run_dir, excluded_providers=route.excluded_providers)
        with patch.object(WebAdapter, "search", return_value="local fixture") as transport:
            for provider, fallback in (("", False), ("bing", False), ("google", False), ("duckduckgo", True)):
                with self.subTest(provider=provider, fallback=fallback), self.assertRaises(CapabilityInputError):
                    adapter.search(None, "fixture", constraints=WebSearchConstraints(provider=provider, allow_fallback=fallback))
            transport.assert_not_called()
            self.assertEqual(adapter.search(None, "fixture", constraints=WebSearchConstraints(
                provider="duckduckgo", allow_fallback=False)), "local fixture")
            transport.assert_called_once()


if __name__ == "__main__":
    unittest.main()
