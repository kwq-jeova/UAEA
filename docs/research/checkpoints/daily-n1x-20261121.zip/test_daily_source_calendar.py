import unittest
from daily_source_calendar import calendar_literals, supplied_years, unique_outputs

class CalendarProvenanceTests(unittest.TestCase):
    def test_missing_year_any_domain(self):
        self.assertEqual(supplied_years('会议日期为2025-03-08','','会议 3/8 08:00'.splitlines()),{'2025-03-08':'3/8'})
    def test_full_year_or_user_supplied_year(self):
        self.assertFalse(supplied_years('记录为2026-11-20','','2026-11-20 已提交'.splitlines()))
        self.assertFalse(supplied_years('2026年11月20日','假设在2026年',['登记处 11/20']))
    def test_invalid_or_different_date(self):
        self.assertFalse(supplied_years('2026-02-30、2026-11-20','',['02/30、11/21']))
    def test_do_not_reject_missing_fields_by_count(self):
        self.assertFalse(supplied_years('只记了11/20，没有年份，无法确认','','登记于11/20'.splitlines()))

    def test_only_visible_date_syntax(self):
        text='折扣 3/8，本表：11/20 16:00；归档于2026-11-20，开会11月21日'
        self.assertEqual(calendar_literals(text),[{'literal':'11/20','year_in_literal':False},{'literal':'2026-11-20','year_in_literal':True},{'literal':'11月21日','year_in_literal':False}])
    def test_embedded_year_is_not_a_partial_date(self):
        self.assertEqual(calendar_literals('2026/11/20 16:00 与 2026年11月20日'),[{'literal':'2026/11/20','year_in_literal':True},{'literal':'2026年11月20日','year_in_literal':True}])

    def test_duplicate_ids_cannot_change_a_visible_source(self):
        item={'type':'function_call_output','call_id':'q','output':'first'}
        self.assertEqual(unique_outputs([item,item]),{'q':'first'})
        self.assertEqual(unique_outputs([item,dict(item,output='second'),item]),{'q':None})
