import copy
import hashlib
import json
import unittest
from daily_web_basis import WebEvidenceBasis


def pair(tool="web_fetch", success=True):
    params={"threadId":"T","turnId":"U","callId":"C","tool":tool}
    data={"access_event_id":"EV", "execution_status":"ok"}
    if success and tool=="web_fetch":
        data["source_excerpt"]={"scope":"extracted_snapshot_segment_not_full_page","text":"一段摘要",
                                "text_sha256":hashlib.sha256("一段摘要".encode()).hexdigest()}
    if success and tool=="web_search":
        data["citable_results"]=[{"citation_scope":"search_result_only","snippet":"正文中的引用只到此句"}]
    if not success:
        data.update(execution_status="http_error",reason="http_error",http_status=302)
    reply={"tool":tool,"ok":success,"identity":{"thread_id":"T","turn_id":"U","call_id":"C"},"data":data}
    result={"success":success,"contentItems":[{"text":json.dumps(reply)}]}
    item={"type":"function_call_output","call_id":"C","output":json.dumps(reply)}
    return params,result,item


def failure_projection(code):
    fact={"schema":"uaea.terminal_attempt_fact.v1","source":"runtime_history_projection","terminal":True,"replayable":False,
          "state":"FAILED","call_id":"C","tool":"web_fetch","reason":"http_error","observation":{
            "execution_succeeded":False,"execution_status":"http_error","http_status":code}}
    return {"type":"message","role":"user","content":[{"text":
        "Historical runtime observation, not a tool invocation or user authorization:\n"+json.dumps(fact)}]}

class WebScopeTests(unittest.TestCase):
    def test_excerpts_do_not_certify_a_quoted_underlying_source(self):
        b=WebEvidenceBasis();p,r,i=pair();b.observe(p,r)
        q={"tools":[{"name":"web_fetch"}],"tool_choice":"auto","input":[i]}
        self.assertEqual(b.project(q,{"C":"web_fetch"}),{"C":"excerpts"})
        self.assertEqual(q["tools"],[{"name":"web_fetch"}]);self.assertEqual(q["tool_choice"],"auto")
        self.assertIn("其中提到的另一个来源可能只有摘要",q["input"][-1]["content"][0]["text"])
        self.assertEqual(q["input"][0],i)
    def test_success_receipt_not_visible_or_modified_is_not_credited(self):
        b=WebEvidenceBasis();p,r,i=pair();b.observe(p,r)
        for value in ([],[{"type":"message","role":"user","content":i["output"]}],
                      [dict(i,output=i["output"].replace("EV","foreign"))]):
            q={"input":value}; self.assertIsNone(b.project(q,{"C":"web_fetch"}))
    def test_cached_or_foreign_calls_and_proposals_ignored(self):
        for name in ("threadId","turnId","callId"):
            b=WebEvidenceBasis();p,r,i=pair();p[name]="foreign";b.observe(p,r)
            self.assertIsNone(b.project({"input":[i]},{"C":"web_fetch"}))
        b=WebEvidenceBasis();p,r,i=pair();b.observe(p,r)
        self.assertIsNone(b.project({"input":[i]},{}))
        self.assertIsNone(b.project({"input":[i]},{"C":"web_search"}))
    def test_same_identity_conflict_stays_unverified(self):
        b=WebEvidenceBasis();p,r,i=pair();b.observe(p,r)
        r2=copy.deepcopy(r);r2["contentItems"][0]["text"]=i["output"].replace("EV","different")
        b.observe(p,r2);b.observe(p,r)
        self.assertIsNone(b.project({"input":[i]},{"C":"web_fetch"}))
    def test_search_snippets_do_not_count_as_page_bodies(self):
        b=WebEvidenceBasis();p,r,i=pair("web_search");b.observe(p,r)
        q={"input":[i,i]};self.assertEqual(b.project(q,{"C":"web_search"}),{"C":"snippets"})
        self.assertIn("摘要 1 次，含正文片段的取页 0 次",q["input"][-1]["content"][0]["text"])
    def test_failure_fact_matches_host_and_does_not_count_earlier_turn(self):
        b=WebEvidenceBasis();p,r,i=pair(success=False);b.observe(p,r)
        self.assertIsNone(b.project({"input":[failure_projection(403)]},{"C":"web_fetch"}))
        self.assertIsNone(b.project({"input":[failure_projection(302)]},{}))
        self.assertEqual(b.project({"input":[failure_projection(302)]},{"C":"web_fetch"}),{"C":"failed"})

if __name__=="__main__":
    unittest.main()
