from copy import deepcopy
from pathlib import Path
import json, re

TAG = "external_uaea.goal_hypotheses"
def without_view(q):
    copy = deepcopy(q)
    keep = []
    removed = []
    for index, item in enumerate(copy["input"]):
        content = item.get("content", [])
        if item.get("role") == "user" and len(content) == 1 and isinstance(content[0],dict):
            text = content[0].get("text","")
            match = re.fullmatch("<"+re.escape(TAG)+">(.*?)</"+re.escape(TAG)+">",text,re.S)
            if match and "id" not in item:
                removed.append((index, json.loads(match.group(1))))
                continue
        keep.append(item)
    copy["input"] = keep
    return copy, removed

def normalize(q, branch_home):
    """Fixture-specific mapping of current identities only. No historical ID replacement."""
    q = deepcopy(q)
    items=q["input"]
    skill, prompt = items[37], items[38]
    assert skill["content"][0]["text"].startswith("<skills_instructions>")
    old_path = str(branch_home) + "/skills/.system"
    assert skill["content"][0]["text"].count(old_path)==1
    skill["content"][0]["text"]=skill["content"][0]["text"].replace(old_path,"<CURRENT_SKILLS_ROOT>")
    for v in (skill,prompt):
        assert v["id"].startswith("msg_")
        v["id"]="<THIS_MESSAGE_ID>"
    meta=q["client_metadata"]
    detail=json.loads(meta["x-codex-turn-metadata"])
    assert meta["turn_id"]==meta["root_turn_id"]==detail["root_turn_id"]==detail["turn_id"]
    for k in ["root_turn_id","turn_id"]:
        meta[k]=detail[k]="<CURRENT_TURN>"
    assert type(detail["turn_started_at_unix_ms"]) is int
    detail["turn_started_at_unix_ms"]="<START_MS>"
    meta["x-codex-turn-metadata"]=detail
    def block(i, tag):
        text=items[i]["content"][0]["text"]
        match=re.fullmatch("<"+re.escape(tag)+">(.*?)</"+re.escape(tag)+">",text,re.S)
        assert match, (i,tag)
        data=json.loads(match[1]);items[i]["content"][0]["text"]={tag:data};return data
    block(39,"uaea.runtime_facts.time")["observed_at_utc"]="<NOW>"
    cur=block(50,"external_uaea.current_user_request")
    assert prompt["content"][0]["text"]==cur["text"]
    iid=cur["input_id"];cur["input_id"]="<CURRENT_INPUT>"
    saved=block(47,"external_uaea.retained_user_requests")
    assert saved["latest_retained_input_id"]==iid
    saved["latest_retained_input_id"]="<CURRENT_INPUT>"
    matches=[u for u in saved["requests"] if u["input_id"]==iid]
    assert len(matches)==1 and matches[0]["text"]==cur["text"]
    matches[0]["input_id"]="<CURRENT_INPUT>"
    semantic=block(48,"uaea.semantic_state_projection")
    interpretation=block(49,"external_uaea.semantic_interpretations")
    assert semantic["effective_state_id"]==interpretation["effective_state_id"]
    semantic["effective_state_id"]=interpretation["effective_state_id"]="<CURRENT_STATE_ID>"
    return q

def check_first(actual_with, actual_without, folder, reference):
    expected=json.loads((reference/"actual-projected-request-1.json").read_text())
    old,old_removed=without_view(expected)
    _,new_removed=without_view(actual_with)
    assert old_removed==new_removed and len(old_removed)==1
    assert [h["candidate_id"] for h in old_removed[0][1]["heads"]]==["goal-candidate:bded94b910097623599608cb"]
    a=normalize(old,reference/"codex-home")
    b=normalize(actual_without,folder/"codex-home")
    if a!=b:
        raise ValueError("FIRST_REQUEST_DRIFT: "+str([k for k in a if a[k]!=b.get(k)])+
                         "; changed input indices="+str([i for i,(x,y) in enumerate(zip(a["input"],b["input"])) if x!=y]))
    return {"normalized_non_view_equal":True,"removed_item":old_removed[0][0],"only_head":old_removed[0][1]["heads"][0]["candidate_id"],"matching_items":len(b["input"]),"historical_ON":str(reference),"same_tools":True,"same_output_budget":True}
