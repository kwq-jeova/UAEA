"""Select a completed tip or verify a sealed interruption for an operator-initiated successor."""
from pathlib import Path
import json
import hashlib

def read(path):
    return json.loads(path.read_text(encoding="utf-8"))

def _file_hash(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def verify_native_origin(run):
    # A previous same-Thread seal can pass a Thread-only check while omitting the latest turn.
    home = Path(read(run / "resume-manifest.json")["native_home"]).resolve(strict=True)
    proof = read(home.parent / "native-copy-proof.json")
    copy = Path(proof["rollout_copy"]).resolve(strict=True)
    relative = copy.relative_to(home)
    original = Path(proof["rollout_original"]).resolve(strict=True)
    if original != (run / "codex-home" / relative).resolve(strict=True):
        raise ValueError("Native seal belongs to another source run")
    if _file_hash(original) != proof["rollout_sha256"]:
        raise ValueError("Sealed Native rollout differs from this run's original")
    # inspect() already checked this exact copy against the recorded seal digest.


def previous(home, inspect):
    runs = (home / "runs").resolve()
    known = set(runs.iterdir()) if runs.is_dir() else set()
    latest = home / "latest.json"
    if not latest.exists():
        if known:
            raise ValueError("Missing latest pointer for nonempty profile; original runs retained")
        return None
    pointer = read(latest)
    source = Path(pointer["checkpoint"]).resolve(strict=True)
    if source.parent != runs or source not in known:
        raise ValueError("Pointer outside this profile's runs")
    _chain(runs, source, pointer["thread"])
    info = inspect(source)
    if (info["thread"] != pointer["thread"] or info["classification"] != "completed"
            or info["complete_response_recorded"] is not True or info["upstream_status"] != "completed"):
        raise ValueError("Selected checkpoint lacks a complete delivery for this Thread")
    verify_native_origin(source)
    return source


def _chain(runs, source, thread):
    known = set(runs.iterdir())
    # A valid old checkpoint can still be stale. Only accept one unbroken, unbranched chain.
    chain = []
    node = source
    while node in known:
        known.remove(node)
        chain.append(node)
        ancestry = read(node / "restore-proof.json")
        if ancestry.get("thread") != thread:
            raise ValueError("Thread mismatch in profile ancestry")
        if ancestry["fresh"] and ancestry.get("source") in ("None",None):
            break
        node = Path(ancestry["source"]).resolve(strict=True)
        if node not in known:
            raise ValueError("Foreign, missing, or cyclic parent in profile ancestry")
    if known:
        raise ValueError("Unaccounted run(s) after selected checkpoint; review required")
    return chain


def reviewed_budget_source(home, inspect):
    """Admit only a new interactive input after a verified, clean request-limit stop."""
    marker = read(home / "needs-review.json")
    runs = (home / "runs").resolve(strict=True)
    source = Path(marker["attempt"]).resolve(strict=True)
    if source.parent != runs or not source.is_dir():
        raise ValueError("Review marker points outside this profile")
    outcome = read(source / "entry-outcome.json")
    if any(marker.get(k) != v for k, v in outcome.items()):
        raise ValueError("Review marker disagrees with recorded outcome")
    thread = read(source / "result.json")["thread"]
    chain = _chain(runs, source, thread)
    pointer = read(home / "latest.json") if (home / "latest.json").exists() else None
    completed = Path(pointer["checkpoint"]).resolve(strict=True) if pointer else None
    if pointer and (pointer["thread"] != thread or completed not in chain[1:]):
        raise ValueError("Stopped tip is not a successor of the completed pointer")
    for node in chain:
        info = inspect(node)
        verify_native_origin(node)
        if node == completed:
            if info['complete_response_recorded'] is not True or info['upstream_status'] != 'completed' or info['classification'] != 'completed':
                raise ValueError("Invalid completed parent of budget stop")
            break
        from daily_delivery_check import REASON, STAGE, verify_text_only_source
        if read(node / "result.json").get("reason") in (REASON,STAGE):
            verify_text_only_source(node,thread)
        else:
            _verify_request_stop(node, thread)
    return source


def verify_request_limit(budget, events, http):
    """Corroborate a clean request-limit stop against admissions and sealed wire records."""
    cap = budget["config"]["max_requests"]
    decision = budget["terminal"]
    admissions = [row for row in events if row.get("event") == "request_admission"]
    if type(cap) is not int or cap < 1 or len(admissions) <= cap:
        raise ValueError("Missing request-limit admission or rejection")
    prepared = [r.get("request_id") for r in http if r.get("event") == "request_prepared"]
    if (len(prepared) != cap or not all(isinstance(r, str) and r for r in prepared)
            or len(set(prepared)) != cap or decision != budget["first_terminal"]
            or decision.get("action") != "stop" or decision.get("status") != "budget_stop"
            or decision.get("reason") != "request_limit" or decision.get("request_count") != cap
            or decision.get("request_allowed") is not False
            or sorted(budget["request_ids"]) != sorted(f"provider-{i}" for i in range(1, cap + 1))):
        raise ValueError("Request-limit decision disagrees with sealed request count")
    for i, row in enumerate(admissions, 1):
        d = row["decision"]
        if (row.get("attempt") != i or
                (i <= cap and (d.get("request_allowed") is not True or d.get("reason") != "request_admitted"
                               or d.get("action") != "continue" or d.get("request_count") != i)) or
                (i > cap and d != decision)):
            raise ValueError("Request-limit admission sequence disagrees with decision")


def _verify_request_stop(node, thread):
    from continuity_checks import build_call_cache
    from input_binding import verify_input_bindings
    outcome = read(node / "entry-outcome.json")
    result = read(node / "result.json")
    reason = "REQUEST_BUDGET_NO_RETRY"
    budget = read(node / "budget-policy-final.json")
    decision = budget["terminal"]
    if (result.get("terminal") != "interrupted" or result.get("classification") != "budget_stop"
            or result.get("reason") != reason or result.get("answers") != []
            or outcome.get("state_recoverable") is not True or outcome.get("delivery_complete") is not False
            or outcome.get("advance_allowed") is not False or outcome.get("entry_error")
            or outcome.get("classification") != "budget_stop" or outcome.get("stop_reason") != reason
            or read(node / "resume-manifest.json").get("stop_reason") != reason
            or decision.get("status") != "budget_stop" or decision.get("reason") != "request_limit"):
        raise ValueError("Only a sealed request-limit stop is eligible")
    def rows(name):
        return [json.loads(s) for s in (node / name).read_text().splitlines()]
    events = rows("budget-events.jsonl")
    verify_request_limit(budget, events, rows("model-http-audit.jsonl"))
    stops = [x["pending"]["turn_id"] for x in events
             if x.get("event") == "interrupt_existing_turn" and x.get("reason") == reason]
    if len(stops) != 1 or not stops[0]:
        raise ValueError("Missing unique interrupted Turn")
    native = rows("app-server-events.jsonl")
    terminals = [m["params"]["turn"]["status"] for row in native if (m := row.get("message", {})).get("method") == "turn/completed"
                 and m["params"].get("threadId") == thread and m["params"]["turn"]["id"] == stops[0]]
    texts = [m["params"]["item"]["content"] for row in native if (m := row.get("message", {})).get("method") == "item/completed"
             and m["params"].get("turnId") == stops[0] and m["params"].get("threadId") == thread
             and m["params"]["item"].get("type") == "userMessage"]
    if (terminals != ["interrupted"] or len(texts) != 1 or len(texts[0]) != 1
            or texts[0][0].get("type") != "text" or texts[0][0].get("text") != read(node / "input.json")["text"]):
        raise ValueError("Stopped turn or original operator input not verified")
    inputs = read(node / "after-state.json")["snapshot"]["workflow_continuity"]["request_continuity"]["inputs"]
    verify_input_bindings(node / "app-server-events.jsonl", thread, inputs)
    receipts = rows("host-rpc-results.jsonl") if (node / "host-rpc-results.jsonl").exists() else []
    if any("result" not in entry for entry in build_call_cache(native, receipts).values()):
        raise ValueError("Historical tool call lacks a receipt")
