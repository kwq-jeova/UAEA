import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import study
from daily_web import DailyToolRegistry, scoped_web_bindings, web_route
from harness.request_continuity import retain_request_input
from harness.semantic_execution_contract import EffectiveContract, SharedExecutionBoundary, record_structured_authority
from runtime.action_request import ActionRequest
from runtime.capability import ToolResult
from runtime.runtime_objects import RuntimeObjectStore, WorkflowRunRecord

URL = "https://example.com/uaea-daily-missing-notice-v1"


class FetchDestinationTests(unittest.TestCase):
    def test_only_one_explicit_https_url_sets_single_destination(self):
        for text in ("/web 只打开 " + URL + " ，告诉我通知日期。",
                     "/web 只读取这个网址：" + URL, "/web 仅访问 `" + URL + "`"):
            with self.subTest(text=text):
                route = web_route(text)
                self.assertEqual(route.names, {"web_fetch"})
                self.assertEqual(route.fetch_targets, (URL,))
                self.assertEqual(route.first_tool, "web_fetch")

    def test_ordinary_fetch_and_action_only_restriction_keep_existing_scope(self):
        self.assertIsNone(web_route("/web 请打开 " + URL).fetch_targets)
        self.assertIsNone(web_route("/web 只可打开网页，不要搜索").fetch_targets)
        self.assertIsNone(web_route("解释“只打开这个网址”", session_web="current").fetch_targets)

    def test_many_missing_or_invalid_destinations_do_not_register_fetch(self):
        for text in ("/web 只打开 " + URL + " 和 https://example.org/",
                     "/web 只打开这个链接", "/web 只打开 a.example/ 或 b.example/",
                     "/web 只打开 http://example.com/", "/web 只打开 https://example.com:9000/"):
            with self.subTest(text=text):
                route = web_route(text)
                self.assertFalse(route.names)
                self.assertEqual(route.fetch_targets, ())
                self.assertIsNone(route.first_tool)

    def test_registered_schema_and_real_host_reject_other_network_or_saved_url(self):
        route = web_route("/web 只打开 " + URL)
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            registry = DailyToolRegistry(study.old.Sandbox(root, root), study.old.LedgerStub(root/"ledger"),
                                         fetch_targets=route.fetch_targets)
            adapter = study.DailyWebAdapter(snapshot_root=root/"snapshots")
            bindings = list(scoped_web_bindings(study.old.repl.register_web_tools(registry, root/"web.sqlite", adapter), route))
            self.assertEqual([b.tool_name for b in bindings], ["web_fetch"])
            self.assertEqual(bindings[0].to_app_server_spec()["inputSchema"]["properties"]["url"]["enum"], [URL])
            store = RuntimeObjectStore()
            store.workflow_runs.append(WorkflowRunRecord(workflow_id="t", task_summary="fixture", status="active"))
            store.active_workflow_id = "t"
            retain_request_input(store, "t", input_id="i", text="只打开 " + URL,
                                 provenance={"source_event_type": "USER_INPUT", "event_id": "i"})
            contract = EffectiveContract("t", "i", "system:fixture", ("web.fetch",))
            record_structured_authority(store, "t", "system:fixture", basis="system_policy",
                                        source_event_id="host:fixture", capabilities=contract.allowed_capabilities)
            host = SharedExecutionBoundary(registry, store, lambda: contract)
            with patch("runtime.tools.ToolRegistry.execute", return_value=ToolResult(True, "CPU", {})) as downstream:
                for i, args in enumerate(({"url": "https://example.org/"},
                                          {"url": "https://example.org/", "source_event_id": "saved-other"},
                                          {"url": URL+"?other=1"}, {"value": URL})):
                    receipt = host.execute(ActionRequest("web.fetch", args, request_id=f"bad-{i}")).result
                    self.assertFalse(receipt.ok)
                    self.assertEqual(receipt.data["execution_status"], "validation_failed")
                    self.assertIs(receipt.data["http_attempted"], False)
                downstream.assert_not_called()
                for i, args in enumerate(({"url": URL},{"url": URL, "source_event_id": "saved-exact"})):
                    self.assertTrue(host.execute(ActionRequest("web.fetch", args, request_id=f"ok-{i}")).result.ok)
                self.assertEqual(downstream.call_count, 2)
