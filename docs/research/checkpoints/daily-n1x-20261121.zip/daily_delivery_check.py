"""Mechanical check for an unexecuted tool envelope at the end of a forced closing reply."""
import hashlib
import json
import re

REASON = "unexecuted_web_call_text"
STAGE = "budget_stage_answer"
CLOSING_NOTE = "这是本轮最后一次模型请求。请直接向用户交付已有证据支持的结果，说明尚未核实或完成的部分。"
def reserve_answer(request, *, compact, last):
    if not last:
        return None
    if compact:
        return "last_slot_native_compaction"
    request["tool_choice"] = "none"
    request["input"].append({"type":"message","role":"developer","content":[{"type":"input_text","text":CLOSING_NOTE}]})
    return "budget_answer_reserved"

_ENVELOPE = re.compile(r"\s*<tool_call>\s*<function=([\w.-]+)>\s*(?:<parameter=[\w-]+>[^<>]*</parameter>\s*)*</function>\s*</tool_call>\s*")

def closing_envelope(text):
    # Permit a factual preamble, but require a raw, standalone trailing call block.
    # Quoted, fenced or inline examples in an explanation stay ordinary prose.
    at=text.rfind("<tool_call>")
    if at<0:
        return None
    prefix=text[:at]
    if not re.fullmatch(r" {0,3}",prefix.rsplit("\n",1)[-1]):
        return None
    fence=None
    for line in prefix.splitlines():
        marker=re.match(r"^ {0,3}(`{3,}|~{3,})(.*)$",line)
        if not marker:
            continue
        run,rest=marker.groups()
        if fence is None:
            fence=run
        elif run.startswith(fence) and not rest.strip():
            fence=None
    return None if fence else _ENVELOPE.fullmatch(text[at:])

def rows(path):
    return [json.loads(s) for s in path.read_text().splitlines()]

def classified_delivery(out, delivery, attempt):
    answers = delivery.get("answers") or []
    if not (delivery.get("delivery_complete") and delivery.get("upstream_status") == "completed" and len(answers)==1):
        return delivery
    match = closing_envelope(answers[0])
    records = rows(out/"budget-events.jsonl")
    reserved = any(r.get("attempt")==attempt and r.get("event")=="budget_answer_reserved" for r in records)
    if not match and not reserved:
        return delivery
    closed = reserved or any(row.get("attempt")==attempt and (
        row.get("event")=="final_answer_after_repeated_unavailable_web" or
        (row.get("event")=="repeated_web_failure" and row.get("final_answer_requested") is True and row.get("tool")==match[1]))
        for row in rows(out/"budget-events.jsonl"))
    if not closed:
        return delivery
    req=json.loads((out/f"actual-projected-request-{attempt}.json").read_text())
    rid=delivery["upstream_request_id"]
    if req.get("tool_choice")!="none":
        raise ValueError("Final-only request for unexecuted tool text not verified")
    digest=hashlib.sha256(json.dumps(req,ensure_ascii=False).encode()).hexdigest()
    http=[x for x in rows(out/"model-http-audit.jsonl") if x.get('request_id')==rid]
    if not (any(x.get('event')=='request_prepared' and x.get('forwarded_bytes_sha256')==digest for x in http)
            and any(x.get('event')=='transport_result' and x.get('response_complete') is True and x.get('http_status')==200 for x in http)):
        raise ValueError("Unverified final-only request/transport")
    if reserved and req["input"][-1].get("content") != [{"type":"input_text","text":CLOSING_NOTE}]:
        raise ValueError("Budget closeout missing from actual request")
    return dict(delivery,delivery_complete=False,answers=[],partial_answers=answers,
                reason=REASON if match else STAGE,upstream_text_complete=True,final_only_attempt=attempt)

def verify_text_only_source(node,thread):
    from continuity_checks import checked_delivery,build_call_cache
    from input_binding import verify_input_bindings
    from upstream_delivery import UpstreamDelivery
    def read(name):return json.loads((node/name).read_text())
    result=read("result.json");outcome=read("entry-outcome.json")
    reason=result.get("reason")
    classification="stage_answer" if reason==STAGE else "task_incomplete"
    if (reason not in (STAGE,REASON) or result["classification"]!=classification or result.get("terminal")!="completed"
            or result.get("answers")!=[] or outcome.get("entry_error")
            or outcome.get("advance_allowed") is not False or outcome.get("delivery_complete") is not False
            or outcome.get("state_recoverable") is not True or outcome.get("stop_reason")!=reason
            or read("resume-manifest.json").get("stop_reason")!=classification):
        raise ValueError("Unexpected text-only delivery status")
    events=rows(node/"app-server-events.jsonl")
    inputs=read("after-state.json")["snapshot"]["workflow_continuity"]["request_continuity"]["inputs"]
    verify_input_bindings(node/"app-server-events.jsonl",thread,inputs)
    turn=result["turn"]
    user_items={p["item"]["id"]:p["item"]["content"] for row in events if (m:=row.get("message",{})).get("method")=="item/completed"
                and (p:=m["params"]).get("threadId")==thread and p.get("turnId")==turn and p["item"].get("type")=="userMessage"}
    if len(user_items)!=1 or [c.get("text") for c in next(iter(user_items.values())) if c.get("type")=="text"] != [read("input.json")["text"]]:
        raise ValueError("Unbound user input for text-only reply")
    native=checked_delivery([row["message"] for row in events if "message" in row],thread,turn)
    recorded=result["delivery_validation"]
    rid=recorded["upstream_request_id"]
    if not isinstance(rid,str) or not re.fullmatch(r"[a-zA-Z0-9_-]+",rid):raise ValueError("Invalid upstream ID")
    upstream=UpstreamDelivery()
    for line in (node/"streams"/rid/"upstream.sse").read_bytes().splitlines():
        if line.startswith(b"data: {"):upstream.observe(rid,json.loads(line[6:]))
    joined=classified_delivery(node,upstream.classify(native,rid),recorded["final_only_attempt"])
    if joined!=recorded or joined.get("reason")!=reason:
        raise ValueError("Unverified text-only final/turn identity")
    receipts=node/"host-rpc-results.jsonl"
    if any("result" not in c for c in build_call_cache(events,rows(receipts) if receipts.exists() else []).values()):
        raise ValueError("Missing retained tool receipt")
