"""Real Native/Host loop against a deterministic loopback provider and synthetic HTTP 302."""
import argparse
import hashlib
import io
import json
import shutil
import subprocess
import sys
import threading
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError
from unittest.mock import patch


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--entry-dir", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--literal-final", action="store_true",
                        help="Verify unexecuted call text is retained as an incomplete delivery, then start a new input")
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    h = args.entry_dir.resolve()
    sys.path.insert(0, str(h))
    import pilot
    study = pilot.study
    url = "https://example.test/repeated-302"
    text = "只打开 " + url + "，请说明本轮能否核实公告日期。"
    answer = ("<tool_call><function=web_fetch><parameter=url>" + url + "</parameter></function></tool_call>"
              if args.literal_final else "该网址返回 HTTP 302，本轮没有取得公告正文，无法核实生效日期。")
    requests = []
    attempts = []

    class Provider(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def do_POST(self):
            request = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            requests.append(request)
            tag = uuid.uuid4().hex
            if request["tool_choice"] == "none":
                item = dict(type="message", role="assistant", status="completed", id="msg-" + tag,
                            content=[dict(type="output_text", text=answer)])
            else:
                item = dict(type="function_call", name="web_fetch", id="item-" + tag, call_id="cpu-"+tag,
                            arguments=json.dumps({"url": url}))
            response_id = "response-" + tag
            events = [dict(type="response.created", response=dict(id=response_id)),
                      dict(type="response.output_item.done", output_index=0, item=item),
                      dict(type="response.completed", response=dict(id=response_id, status="completed",
                           incomplete_details=None, usage=dict(input_tokens=1000, output_tokens=40, total_tokens=1040)))]
            payload = "".join("data: " + json.dumps(event) + "\n\n" for event in events).encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)

    def fixture_server():
        server = ThreadingHTTPServer(("127.0.0.1", 18437), Provider)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        return server

    def synthetic_http(self, request, *, timeout):
        attempts.append(request.full_url)
        if request.full_url != url:
            raise AssertionError("Unexpected CPU test destination")
        raise HTTPError(url, 302, "Found", {}, None)

    make_app = study.make_app
    def authorized_app(out, store, guard, cpu_route):
        # Production CPU fixtures are offline. Exercise the live registry/contract
        # with this single explicitly requested capability and substitute transport only.
        route = study.web_route("/web " + text)
        assert route.names == {"web_fetch"}
        return make_app(out, store, guard, route)

    profile = "repeat-302-" + uuid.uuid4().hex[:8]
    try:
        with patch.object(study, "cpu_server", fixture_server), patch.object(study, "make_app", authorized_app), \
                patch.object(study.DailyWebAdapter, "open_request", synthetic_http), \
                patch.object(sys, "stdin", io.StringIO("/web " + text + "\n/quit\n")), \
                patch.object(sys, "argv", ["pilot", "--cpu-fixture", "--profile", profile]):
            pilot.main()
    finally:
        print("CPU profile:", h / "cpu-profiles" / profile)
    def read(p):
        return json.loads(p.read_text())
    home = h / "cpu-profiles" / profile
    marker = home / "needs-review.json"
    pointer = home / "latest.json"
    run = Path(read(marker)["attempt"] if args.literal_final else read(pointer)["checkpoint"])
    events = [json.loads(line) for line in (run / "budget-events.jsonl").read_text().splitlines()]
    repeated = [e for e in events if e["event"] == "repeated_web_failure"]
    result = read(run / "result.json")
    replies = [json.loads(item["contentItems"][0]["text"]) for item in result["new_calls"]]
    audit = [json.loads(line) for line in (run / "model-http-audit.jsonl").read_text().splitlines()]
    prepared = [row["request_id"] for row in audit if row["event"] == "request_prepared"]
    transported = [row for row in audit if row["event"] == "transport_result"]
    assert len(requests) == len(prepared) == len(transported) == 4
    assert all(row["http_status"] == 200 and row["response_complete"] for row in transported)
    assert [q["tool_choice"] for q in requests] == ["auto", "auto", "auto", "none"]
    assert attempts == [url] * 3 and len(replies) == 3
    assert all(r["status"] == "http_failure" and r["data"]["http_status"] == 302 for r in replies)
    assert [(e["attempt"], e["final_answer_requested"]) for e in repeated] == [(3, False), (4, True)]
    assert repeated[-1]["provider_request_ids"] == prepared[:3]
    assert [r["identity"]["call_id"] for r in replies] == repeated[-1]["call_ids"]
    assert result["delivery_validation"]["upstream_status"] == "completed"
    outcome = read(run / "entry-outcome.json")
    successor = None
    if args.literal_final:
        assert result["terminal"] == "completed" and result["classification"] == "task_incomplete"
        assert result["answers"] == [] and result["delivery_validation"]["partial_answers"] == [answer]
        assert result["reason"] == "unexecuted_web_call_text"
        assert outcome["state_recoverable"] and not outcome["advance_allowed"] and not outcome["delivery_complete"]
        assert not pointer.exists()
        original = (run / "result.json").read_bytes()
        original_receipts = (run / "host-rpc-results.jsonl").read_bytes()
        next_text = "下一条独立请求：请使用本地 CPU 材料。"
        closed = subprocess.run([sys.executable, "-B", str(h / "pilot.py"), "--cpu-fixture", "--profile", profile],
                                input=next_text + "\n/quit\n", text=True, capture_output=True,
                                timeout=90, cwd=h)
        if closed.returncode:
            raise RuntimeError("New-input CPU recovery failed: " + closed.stdout[-1200:] + closed.stderr[-1200:])
        assert not marker.exists() and pointer.exists()
        new = Path(read(pointer)["checkpoint"])
        proof = read(new / "restore-proof.json")
        completed = read(new / "result.json")
        assert proof["source"] == str(run) and proof["new_process"] and proof["original_process_absent"]
        assert proof["new_model_requests_during_restore"] == proof["new_tool_dispatches_during_restore"] == 0
        assert proof["full_Host_state_equal"] and proof["Journal_bytes_equal"] and proof["normalizer_restored"]
        assert read(new / "input.json")["text"] == next_text and completed["thread"] == result["thread"]
        assert read(new / "entry-outcome.json")["advance_allowed"] and completed["turn"] != result["turn"]
        assert [c["tool"] for c in completed["new_calls"]] == ["read_section"]
        assert completed["delivery_validation"]["delivery_complete"] and completed["answers"]
        assert (run / "result.json").read_bytes() == original
        assert (run / "host-rpc-results.jsonl").read_bytes() == original_receipts
        successor = dict(path=str(new), thread=completed["thread"], turn=completed["turn"],
                         restore=proof, calls=[c["tool"] for c in completed["new_calls"]], answers=completed["answers"])
    else:
        assert result["answers"] == [answer] and outcome["delivery_complete"] and outcome["advance_allowed"]
    assert read(run / "budget-policy-final.json")["config"]["max_requests"] == 6
    report = dict(run=str(run), scope="real Native/Host; synthetic model and HTTP 302, loopback provider only",
                  model_request_ids=prepared, host_call_ids=repeated[-1]["call_ids"],
                  host_observed_http_status=[302] * 3, repeated_events=repeated, answers=result["answers"],
                  delivery_complete=outcome["delivery_complete"], advance_allowed=outcome["advance_allowed"],
                  classification=result["classification"], new_input_successor=successor, external_network_requests=0)
    raw = args.output.with_name(args.output.stem + "-raw")
    raw.mkdir(exist_ok=False)
    for name in ("app-server-events.jsonl", "host-rpc-results.jsonl", "model-http-audit.jsonl", "result.json",
                 "budget-events.jsonl", "budget-policy-final.json", "entry-outcome.json"):
        shutil.copyfile(run / name, raw / name)
    for path in run.glob("actual-projected-request-*.json"):
        shutil.copyfile(path, raw / path.name)
    if successor:
        for name in ("entry-outcome.json", "restore-proof.json", "result.json"):
            shutil.copyfile(Path(successor["path"]) / name, raw / ("next-" + name))
    report["raw_records"] = str(raw)
    report["raw_sha256"] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(raw.iterdir())}
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print("PASS", args.output)

if __name__ == "__main__":
    main()
