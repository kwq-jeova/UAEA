# 人工自然会话研究入口（限定可用）

本入口接续现有隔离研究路径；不是正式产品入口或通用 Runtime 恢复器。不会启动模型，不会导入任何历史种子或旧用户内容。仅连接外部已启动、受现有 Guard 保护的 Nemotron Bolt 服务。

## Windows 最简使用

先按项目原有方式启动受保护的 56/72、64K、1 GiB KV、单并发服务。该步骤由原 Supervisor/Guard 负责，本入口不更改或重启它。服务已就绪时，在 PowerShell 中执行：

~~~powershell
wsl.exe -d Ubuntu-24.04 -- python3 /home/wqkan_wsl/uaea-n1x/research-records/m4-human-ready-20261119-v1/pilot.py --profile daily
~~~

输入一条用户消息，等待完整回答后再输入下一条。当前为单行终端输入；不要输入 /compact 等本入口未实现的命令。输入 /quit 正常退出。次日重新启动受保护服务后，再执行同一命令、使用同一个 profile，恢复最近一次完整封存的同一 Harness Thread。新 profile 从空状态开始，不自动继承其他 profile 的候选。

本地文件读取限于当前 profile 的 workspace，例如 daily 使用 real-user/daily/workspace/。日常消息默认离线。要查公开网页，直接输入 `/web 查询主题`，例如 `/web google搜索 IANA Example Domains，用英文搜索，中文回答`。明确查询的首步是网页搜索，给出单个目标网址可直接读取；“可以按需联网”保留工具选择。也可以单独输入 `/web`。紧接同线程上一条已交付、明确要求搜索且没有发起任何网页调用的请求时，它接续该查询；否则出现“联网查询>”，输入主题即可，空行取消。以上方式按轮授权。一次会话中连续研究多个对象，可单独输入 `/web on` 开启本窗口的按需联网，之后直接说要分析什么。明确另行研究新对象时先搜该对象，普通讨论和“如需资料可以联网”仍由模型按需决定。说“本轮不要联网”可临时跳过，`/web off` 关闭；退出、重启和切换 profile 均不会恢复旧授权。终端命令只写入本地审计记录，不作为模型用户轮发送。查看答复后的 [UAEA Host] 状态行可核对实际调用和成功回执数。搜索取得链接，页面正文以读取回执为准。网页回执及快照在该轮记录和当前 profile 的 web-sources 目录中。

## 保存、隔离与失败处理

- 自然会话独立保存在 real-user/<profile>/；CPU 固定夹具在 cpu-profiles/，Native 封存分别放 sealed/live/ 与 sealed/pilot-cpu-*/。没有从 CPU 到自然会话的状态导入。
- 每轮保留 Native/HTTP、Host 状态、Goal Journal、出站投影和封存副本。不要删除或编辑当前 latest 指向的目录、原始 Journal 或封存目录。逐轮保存会增长；尚未测存储上限、长期磁盘成本或长期自然对话表现。
- 这是本地明文研究记录，不提供加密、身份验证或多用户隔离。新建文件使用 umask 077；WSL 权限不能替代 Windows 账户/磁盘保护。建议先使用匿名、无敏感内容的研究材料。
- 同 profile 加排他锁，不能同时开两个会话；不同 profile 的同时 GPU 使用仍受原单并发配置约束，建议只开一个。
- 旧进程必须真实结束且封存成功，本轮同时满足完整交付，才更新 latest。可恢复状态与完整交付分别写入 entry-outcome.json；Native 已确认终止且缓存完整，只能说明状态可恢复，不能证明用户已收到完整交付。未完整交付均保留 needs-review.json。若单轮模型请求次数用完，交互入口会核验同一 Thread 的终止事件、原始输入、Host 封存、工具回执和完整父链，核验通过后等待下一条用户消息。只退出会保留现场，历史调用不会重放，latest 仍指向上次完整交付。其他停止原因、上游截断、核验冲突和无人交互的批处理继续保持暂停。不要手动删标记继续；先核对该轮记录。没有自动重试、自动绕过或自动丢弃失败轮。
- 连接时自动查找唯一存活 Guard，并核对模型/窗口、PID 身份、single_clock_v1、真实 heartbeat 序号前进及两侧遥测有效性。无 Guard、多个疑似 Guard、Guard 已停或遥测无效均拒绝请求。已有资源停止线由原 Guard 执行，不被本入口修改。现有 Guard 的实际策略以其原件为准。
- 单轮沿用 6 个 Provider 请求、3072 输出 Token、600 秒硬上限；软预算是观测阈值。此处预算不能保证模型一定完成任务。

## Daily 多轮联网验收（2026-11-21）

日常使用仍用上方的 PowerShell 命令。连续跨对象研究可输入 `/web on`；本轮明确禁止联网会覆盖它。重新启动入口后窗口授权清除。只查询一次可用 `/web 查询内容`。明确要求只打开一个网址时，Host 同时限制网络目标和快照来源。若系统显示上一轮只留下工具调用文本，那段文本没有执行；入口核验封存后，可直接输入新的请求。资源中断或封存冲突仍需要审查。

在本目录运行以下命令。真实验收使用独立 rehearsal 档案和已就绪的 Guard，输出目录须尚不存在。一次跑三个进程、六条用户消息。命令退出码检查连线、授权、恢复和可识别的未交付。逐轮答复还要按 plan 中的材料判读；`wire-and-delivery.json` 列出每个 Call 第一次实际送达的请求和证据。

```bash
python3 -B daily_acceptance.py cpu
python3 -B daily_acceptance.py plan
python3 -B daily_acceptance.py live /tmp/uaea-daily-acceptance-new
python3 -B daily_acceptance.py audit /tmp/uaea-daily-acceptance-new
```

本地协议回归用真实 Harness 与 CPU 替身服务，两个命令顺序运行，各用新的输出路径。

```bash
python3 -B cpu_repeated_web_protocol.py --output /tmp/uaea-302-normal.json
python3 -B cpu_repeated_web_protocol.py --literal-final --output /tmp/uaea-302-literal.json
```

## Goal 权限

实际注册 actor 已在 GoalResearch 构造后校正为 operator；自然输入来源标记为 operator_supplied/researcher_authored=false。CPU 输入单独标 cpu_fixture/true。没有向自然会话添加“可提议修订”的额外邀请或 SIM 材料说明。

Goal Sideband 仅保存非权威假设，CURRENT 引用、版本、来源和 Scope 校验继续由 Host 执行；不自动采纳 Active Goal 或 Memory，不代替模型修订。新会话仍为同一 Thread 的续用，不代表任意新 Thread/不同 Workflow 自动共享 Global Goal。Global family 绑定以及跨 Workflow 的人工管理入口仍未接入；不要手工改封存 Journal 来实现它。

## 本次实测边界

51 项 CPU 协议检查通过，详见 cpu-proof-final.json 和 verify_cpu.py。使用真实 linux-aarch64 Codex 0.170.0（显式二进制路径，不改变仓库的 0.163 默认版本登记）+ CPU 假 SSE 服务：
1. 第一进程实际经过 Native Tool Call 提交一个明确标注 CPU 的合法 form，Host 保存。
2. 第二进程恢复相同 Thread，Host/Normalizer/Journal 一致，无历史工具重执行；相同 head 和正文真实进入新的出站请求。
3. 检查 actual actor、当前 Goal View 严格校验、无 SIM/额外许可句、工作根、并发锁、失败锁、/quit、停止 Guard 拒绝以及文件读取边界。

这是固定 CPU 协议夹具，不证明模型自主形成或忠实维护 Goal。本入口新增自然用户轮次为 0、GPU 请求为 0；实际跨日、长期自然表现尚未测。01:03:13 UTC 曾只读通过当时活动 Guard readiness；这不是明日服务已启动的保证，明日会重新检查。

依赖当前 dirty 研究代码和旧研究模块的类/工具实现，但没有读取旧实验内容作为用户历史。实现文件为本目录 pilot.py 与复制的 study.py，正式仓库未因本子任务修改。initial-cpu-driver/ 保留升级前局部 CPU 验证件；goal170 是 CPU form 模式尚未传入 run_from 时的固定读取检查，不计为 Goal 提交成功。最终合法 form 的完整两进程结果位于 cpu-profiles/goalform170/。


## 终检修正

入口现将“封存可恢复”与“本轮完整交付”分开记录。预算停止、执行/资源故障、外部中断以及真实上游 incomplete 均不会自动推进；即使状态可恢复，也保留现场、打印未完整交付并锁住 profile，等待审查。needs-review 检查位于排他锁成功之后，避免竞争条件。此前仅以 resume_eligible 放行的入口不具备这项保证；本节记录 11 月 19 日的策略；11 月 21 日加入的、仅限请求数耗尽的交互式恢复见上文。CPU 分支反例见 entry-outcome-cpu.json；未重新运行 GPU。

## 2026-11-19 自然使用准备复核

人工入口仍使用本脚本的 daily profile。独立的 rehearsal 模式跑通了同一入口的三轮 Bolt、正常退出与同 Thread 恢复。受控输入保存在 rehearsal-profiles，真人档案保存在 real-user。研究侧不会把演练记作真人反馈。

收尾版本在选用封存和发布新指针时核对来源。加入 Input 与 Native 用户消息的身份校验，压缩控制轮单列。上游截断、真实等待中断、损坏或来源冲突都会停止自动推进。两进程 Bolt 使用的版本与事后 CPU 故障修订均有留档。本轮 CPU 真实 Native 协议复核了候选经过独立压缩、重启后进入下一次实际 HTTP 的路径。长期自然压力压缩与是否减轻用户负担仍待观测。

控制端使用步骤、原始回执、负例和逐轮证据索引见 UAEA_DOCS/20261119_M4NaturalUseReadiness。自然用户只要提工作，出现未验证状态时保留现场。只读索引命令位于相邻研究目录 m4-natural-readiness-20261119-v1/evidence-tools/README.md。
