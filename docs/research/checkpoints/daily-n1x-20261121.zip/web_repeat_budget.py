"""Bound a repeated failed web action within one daily Turn using Host receipts."""
import json
import threading


def _failure(params, result):
    tool = params.get("tool")
    if tool not in ("web_search", "web_fetch") or not isinstance(result, dict) or result.get("success") is not False:
        return None
    content = result.get("contentItems")
    if not isinstance(content, list) or len(content) != 1 or not isinstance(content[0], dict):
        return None
    try:
        receipt = json.loads(content[0]["text"])
    except (ValueError, TypeError, KeyError):
        return None
    if not isinstance(receipt, dict) or receipt.get("ok") is not False or receipt.get("tool") != tool:
        return None
    identity = receipt.get("identity")
    if not isinstance(identity, dict) or any(
            not params.get(rpc) or params[rpc] != identity.get(field)
            for rpc, field in (("callId", "call_id"), ("threadId", "thread_id"), ("turnId", "turn_id"))):
        return None
    data = receipt.get("data")
    status = receipt.get("status")
    if (not isinstance(data, dict) or data.get("execution_succeeded") is not False
            or data.get("execution_status") != status):
        return None
    if status == "validation_failed" and data.get("http_attempted") in (False, None):
        if data.get("failure_stage") == "contract_validation":
            kind = "contract_validation"
        elif data.get("validation_source") == "capability_input" and data.get("http_attempted") is False:
            kind = "capability_input"
        else:
            return None
        detail = [data.get("reason"), data.get("failure_scope"), data.get("effective_state_id"),
                  data.get("error_kind"), data.get("unsupported_fields")]
    elif status == "http_failure" and data.get("http_attempted") is True and type(data.get("http_status")) is int:
        kind, detail = status, [data["http_status"], data.get("reason")]
    elif status == "network_failure" and data.get("http_attempted") is True and data.get("reason"):
        kind, detail = status, [data["reason"], data.get("transport_failure")]
    else:
        return None
    if not isinstance(params.get("arguments"), dict):
        return None
    # Omit call/observation IDs from equality; compare exact JSON values including
    # provider, fallback flags and URL/query, without interpreting the content.
    key = json.dumps([params["threadId"], params["turnId"], tool, params["arguments"], kind, detail],
                     sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return kind, key


_DESCRIPTIONS = {
    "contract_validation": "Host 在执行前根据本轮约束拒绝了该提案",
    "capability_input": "Host 在发起联网前拒绝了该组参数",
    "http_failure": "该网页请求收到相同的 HTTP 失败状态",
    "network_failure": "该网页请求遇到相同类别的网络故障",
}


class RepeatedWebFailure:
    def __init__(self):
        self.seen = set()
        self.proposals = {}
        self.failure = None
        self.calls = []
        self.requests = []
        self.tool = None
        self.lock = threading.Lock()

    def proposed(self, request_id, call_id, tool):
        with self.lock:
            self.proposals[call_id] = (request_id, tool)

    def observe(self, params, result):
        """Called for newly formed live RPC results, never for historical cache replies."""
        call_id = params.get("callId")
        with self.lock:
            if not call_id or call_id in self.seen:
                return
            self.seen.add(call_id)
            failure = _failure(params, result)
            proposal = self.proposals.get(call_id)
            if not proposal or proposal[1] != params.get("tool"):
                failure = None
            if failure is None or failure != self.failure:
                self.calls = []
                self.requests = []
            self.failure = failure
            self.tool = params.get("tool")
            if failure is not None:
                self.calls.append(call_id)
                if proposal[0] not in self.requests:
                    self.requests.append(proposal[0])

    def project(self, request, *, last_request):
        with self.lock:
            if len(self.requests) < 2 or self.tool not in {t.get("name") for t in request["tools"]}:
                return None
            kind = self.failure[0]
            final = len(self.requests) >= 3 or last_request
            message = f"本轮连续 {len(self.calls)} 次向 {self.tool} 提交相同参数，{_DESCRIPTIONS[kind]}。"
            if final:
                request["tool_choice"] = "none"
                message += "请直接交付能用现有材料核实的部分，指出仍缺的证据。"
            else:
                message += "可依照回执修正参数、选用其他已开放的来源，或用现有材料作答。"
            request["input"].append({"type": "message", "role": "developer", "content": [
                {"type": "input_text", "text": message}]})
            return {"failure_kind": kind, "tool": self.tool, "call_ids": list(self.calls),
                    "provider_request_ids": list(self.requests),
                    "final_answer_requested": final}
