"""Daily web budget containment; a retained refusal is not a new attempted operation."""
import threading
import unittest
from unittest.mock import patch
import study
from copy import deepcopy

from daily_web import web_route
from study import restrict_repeated_unavailable_web


class OfflineBudgetTests(unittest.TestCase):
    def setUp(self):
        self.proposals = {"c1": "web_search", "c2": "web_search"}
        self.errors = [dict(type="function_call_output",call_id=x,output="unsupported call: web_search")
                       for x in self.proposals]
        self.request = dict(input=list(self.errors),tools=[{"name":"read_section"}],tool_choice="auto")

    def test_two_new_rejections_leave_a_final_answer(self):
        self.assertTrue(restrict_repeated_unavailable_web(self.request,self.proposals))
        self.assertEqual(self.request["tool_choice"],"none")
        self.assertEqual(self.request["input"][:-1],self.errors)
        self.assertIn("未执行",self.request["input"][-1]["content"][0]["text"])

    def test_old_or_one_current_rejection_leaves_normal_selection(self):
        for current in ({},{"c2":"web_search"},{"new":"web_search"}):
            q=deepcopy(self.request)
            self.assertFalse(restrict_repeated_unavailable_web(q,current))
            self.assertEqual(q,self.request)

    def test_same_call_twice_not_two_attempts(self):
        self.request["input"]=[self.errors[0],self.errors[0]]
        self.assertFalse(restrict_repeated_unavailable_web(self.request,self.proposals))

    def test_wrong_error_or_mismatched_tool_not_a_router_refusal(self):
        for output in ("HTTP 403","unsupported call: web_fetch"):
            self.request["input"][1]["output"]=output
            self.assertFalse(restrict_repeated_unavailable_web(self.request,self.proposals))

    def test_available_web_is_untouched(self):
        self.request["tools"].append({"name":"web_search"})
        self.assertFalse(restrict_repeated_unavailable_web(self.request,self.proposals))

    def test_same_method_requires_current_permission(self):
        text="用同样的方法分析soxx"
        self.assertFalse(web_route(text).names)
        self.assertEqual(web_route(text,session_web="grant").first_tool,"web_search")
        self.assertFalse(web_route(text+"，只用现有资料",session_web="grant").names)


class CompactPhaseTests(unittest.TestCase):
    def setUp(self):
        self.bridge=study.Capture.__new__(study.Capture)
        self.bridge._lock=threading.Lock()
        self.bridge._compaction_turn_id=None
        self.bridge.phase_change=threading.Condition()
        stub=patch.object(study.old.Original,"restore_runtime_context",return_value=("projected",[]))
        self.project=stub.start()
        self.addCleanup(stub.stop)

    def test_empty_tools_without_native_event_fail_closed(self):
        with patch.dict(study.P["limits"],poll_seconds=0):
            with self.assertRaisesRegex(ValueError,"Native compaction lifecycle"):
                self.bridge.synchronized_projection({"tools":[]})
        self.project.assert_not_called()

    def test_http_and_native_may_arrive_in_either_order(self):
        for active in (True,False):
            tools=[] if active else [{"name":"read_section"}]
            timer=threading.Timer(.02,self.bridge.set_compaction,args=("turn-1",active))
            timer.start()
            try:
                self.assertEqual(self.bridge.synchronized_projection({"tools":tools}),("projected",[]))
                self.assertEqual(self.bridge._compaction_turn_id is not None,active)
            finally:
                timer.join()

    def test_explicit_compaction_route_does_not_wait(self):
        self.bridge.synchronized_projection({"tools":[]},compact=True)
        self.project.assert_called_once_with({"tools":[]},compact=True)


if __name__=="__main__":
    unittest.main()
