"""User-visible calendar provenance for a reply explicitly restricted to one URL."""
import hashlib
import json
import re
from datetime import date

ABSOLUTE = re.compile(r"(?<!\d)((?:19|20)\d{2})\s*[-/.年]\s*(\d{1,2})\s*[-/.月]\s*(\d{1,2})(?:日)?(?!\d)")

def supplied_years(answer, user_text, excerpts):
    source="\n".join(excerpts)
    found={}
    for match in ABSOLUTE.finditer(answer):
        year,month,day=map(int,match.groups())
        try: normalized=date(year,month,day).isoformat()
        except ValueError: continue
        if normalized in found or re.search(rf"(?<!\d){year}(?!\d)",source+"\n"+user_text):
            continue
        for literal in calendar_literals(source):
            if literal['year_in_literal']:
                continue
            md=re.findall(r"\d+",literal['literal'])
            if list(map(int,md))==[month,day]:
                found[normalized]=literal['literal']
                break
    return found

def unique_outputs(items):
    visible={}
    for item in items:
        if item.get("type")!="function_call_output" or not item.get("call_id"):
            continue
        cid=item["call_id"]
        value=item.get("output")
        if cid not in visible:
            visible[cid]=value if isinstance(value,str) else None
        elif visible[cid]!=value:
            visible[cid]=None
    return visible

def calendar_notice(out,result):
    """Join the final wire body to its transport, current Host receipt and visible excerpt."""
    if not any(c.get("tool")=="web_fetch" and c.get("success") is True for c in result.get("new_calls",[])):return
    delivery=result.get("delivery_validation",{})
    rid=delivery.get("upstream_request_id")
    if not rid or not result.get("answers") or delivery.get("delivery_complete") is not True:
        return
    def read(p):return json.loads(p.read_text())
    def rows(p):return [json.loads(l) for l in p.read_text().splitlines()] if p.exists() else []
    traffic=[v for v in rows(out/"model-http-audit.jsonl") if v.get("request_id")==rid]
    if not any(v.get("event")=="transport_result" and v.get("response_complete") is True and v.get("http_status")==200 for v in traffic):
        return
    prep=[v for v in traffic if v.get("event")=="request_prepared"]
    if len(prep)!=1:return
    p=out/("actual-projected-request-"+str(prep[0]["sequence"])+".json")
    if not p.is_file():return
    q=read(p)
    if hashlib.sha256(json.dumps(q,ensure_ascii=False).encode()).hexdigest()!=prep[0]['forwarded_bytes_sha256']:return
    defs={v['name']:v for v in q.get("tools",[]) if v.get('name') in ('web_search','web_fetch')}
    if set(defs)!={'web_fetch'}:return
    urls=defs['web_fetch'].get('parameters',{}).get('properties',{}).get('url',{}).get('enum')
    if not isinstance(urls,list) or len(urls)!=1:return
    visible=unique_outputs(q.get('input',[]))
    excerpts={}
    for row in rows(out/'host-rpc-results.jsonl'):
        params=row['params']
        if (params['turnId'],params['threadId'])!=(result.get('turn'),result.get('thread')):continue
        if row.get('result',{}).get('success') is not True:continue
        if params['tool']!='web_fetch':return
        cid=params['callId']
        if params['arguments'].get('url')!=urls[0] or cid!=row.get('call_id'):return
        if not isinstance(visible.get(cid),str):continue
        reply=read_receipt(row['result']['contentItems'][0]['text'])
        if not reply or reply!=read_receipt(visible[cid]) or reply.get('ok') is not True:continue
        identity=reply.get('identity') or {}
        if (identity.get('call_id'),identity.get('turn_id'),identity.get('thread_id'))!=(cid,params['turnId'],params['threadId']):continue
        body=(reply.get('data') or {}).get('source_excerpt') or {}
        text=body.get('text')
        if text and body.get('scope')=='extracted_snapshot_segment_not_full_page' and hashlib.sha256(text.encode()).hexdigest()==body.get('text_sha256'):
            excerpts[cid]=text
    if not excerpts:return
    flagged=supplied_years("\n".join(result['answers']),read(out/'input.json')['text'],excerpts.values())
    if not flagged:return
    pairs='；'.join(f'答复提及 {k}，本轮送达的指定来源片段只可找到 {v}，缺少对应年份' for k,v in flagged.items())
    return dict(scope="single_url_current_turn_visible_excerpts",request_id=rid,call_ids=list(excerpts),
                added_calendar_year=flagged,source_verification="unconfirmed",
                notice="[UAEA Host · 来源核对] "+pairs+"。依赖这一完整日期的结论尚未核实。")

def read_receipt(value):
    try:return json.loads(value)
    except (ValueError,TypeError):return None

# An unlabelled ratio is not a date. Accept month/day without a year only in a
# dated Chinese expression or immediately before a clock time in the excerpt.
_PARTIAL = re.compile(r"(?<![\d/.-])(?:(\d{1,2})月(\d{1,2})日|(\d{1,2})/(\d{1,2})(?=\s+\d{1,2}:\d{2}))(?!\d)")

def calendar_literals(text):
    matches=[]
    for m in ABSOLUTE.finditer(text):
        try:date(*(int(v) for v in m.groups()))
        except ValueError:continue
        matches.append((m.start(),m.end(),m[0],True))
    for m in _PARTIAL.finditer(text):
        if any(a<=m.start()<b for a,b,_,_ in matches):continue
        try:date(2000,int(m[1] or m[3]),int(m[2] or m[4]))
        except ValueError:continue
        matches.append((m.start(),m.end(),m[0],False))
    return [dict(literal=t,year_in_literal=y) for a,b,t,y in sorted(matches)]

def project_calendar_literals(q,verified):
    """verified contains only current Host receipts corroborated in THIS wire input."""
    if not verified:return
    by_name={d.get('name'):d for d in q.get('tools',[]) if d.get('name') in ('web_fetch','web_search')}
    enum=(by_name.get('web_fetch',{}).get('parameters',{}).get('properties',{}).get('url',{}).get('enum'))
    if set(by_name)!={'web_fetch'} or not isinstance(enum,list) or len(enum)!=1:return
    rows=[]
    for cid,output in unique_outputs(q.get('input',[])).items():
        if not output or verified.get(cid)!='excerpts':continue
        reply=read_receipt(output)
        if not isinstance(reply,dict):continue
        excerpt=(reply.get('data') or {}).get('source_excerpt') or {}
        if not isinstance(excerpt.get('text'),str):continue
        literals=calendar_literals(excerpt['text'])
        if literals and len(rows)<4:
            rows.append(dict(call_id=cid,source_event_id=excerpt.get('source_event_id'),dates=literals[:4],omitted_dates=max(0,len(literals)-4)))
    if rows:
        q['input'].append(dict(type='message',role='developer',content=[dict(type='input_text',text='本轮指定网页可见正文中的日期原文（抽样，year_in_literal 仅表示该串自带年份）\n'+json.dumps(rows,ensure_ascii=False,separators=(',',':')))]))
