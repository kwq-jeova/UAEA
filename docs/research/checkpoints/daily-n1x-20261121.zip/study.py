"""Isolated research driver; existing Harness owns execution and compaction."""
from pathlib import Path
from copy import deepcopy
from datetime import datetime
import argparse,hashlib,importlib.util,json,pickle,re,shutil,signal,threading,time,uuid,os
B=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location("old_supplier",B.parent/"supplier-task-handoff-20261115-v3/study.py")
old=importlib.util.module_from_spec(sp);sp.loader.exec_module(old)
from daily_web import DailyToolRegistry, scoped_web_bindings, DailyWebAdapter, TurnReadOnlyHost, current_web_notice, stage_resume_catalogue, WebRoute, web_route, WEB_NAMES
from budget_policy import BudgetPolicy,BudgetConfig
from web_repeat_budget import RepeatedWebFailure
from daily_web_basis import WebEvidenceBasis
from daily_source_calendar import project_calendar_literals
from input_binding import isolated_input_consumer, verify_input_bindings
from continuity_checks import SSEProgress,build_call_cache,started_turn_id,checked_delivery
P=json.loads((B/"plan.json").read_text())
INPUT_ORIGIN="operator_supplied"
ACTIVE=None;ARM=None;PHASE=None;POLICY=None;CPU=False;CPU_MODE=None;CPU_RUN_NAME="cpu"
def dump(p,v):
 p.parent.mkdir(parents=True,exist_ok=True);t=p.with_suffix(p.suffix+".tmp")
 t.write_text(json.dumps(v,ensure_ascii=False,indent=2)+"\n");t.replace(p)
def append(p,v):
 with p.open("a",encoding="utf-8")as f:f.write(json.dumps(v,ensure_ascii=False)+"\n");f.flush()
def digest(data):return hashlib.sha256(data).hexdigest()
rows=old.rows
class StopRequested(RuntimeError):pass
class OperatorInterrupted(RuntimeError):pass
def budget_stop_reason(decision):
 return "REQUEST_BUDGET_NO_RETRY" if decision["reason"]=="request_limit" else decision["reason"]
def guard_check(guard):
 if guard is None:return
 old.check_guard(guard)
 if (guard/"monitor-exception.json").exists():raise StopRequested("RESOURCE_MONITOR_FAILURE")
from upstream_delivery import UpstreamDelivery
import daily_delivery_check
from research.goal_view_condition import prepare_goal_view
def restrict_repeated_unavailable_web(q, emitted):
 if not emitted or any(t.get("name") in WEB_NAMES for t in q["tools"]):
  return False
 rejected={item["call_id"] for item in q["input"] if item.get("type")=="function_call_output"
           and item.get("call_id") in emitted and item.get("output")=="unsupported call: "+emitted[item["call_id"]]}
 if len(rejected)<2:
  return False
 q["tool_choice"]="none"
 q["input"].append({"type":"message","role":"developer","content":[{"type":"input_text","text":
     "本轮网页工具未开放，两次调用均未执行。现在直接交付能用现有材料核实的部分，标明尚缺的资料。"}]})
 return True

class Capture(old.Original):
 def __init__(self,*a,**kw):
  self.count=0;self.out=ACTIVE;self.arm=ARM;self.phase=PHASE;self.policy=POLICY;self.budget_stop=None;self.buffers={};self.event_sequences={};self.first_exception=None
  self.received_at=json.loads((self.out/"input.json").read_text())["received_at"]
  self.sink=old.CaptureSession(Path(kw["audit_path"]).with_name("streams"),old.Budget())
  self.upstream_delivery=UpstreamDelivery()
  self.answer_only=False
  self.phase_change=threading.Condition()
  self.emitted_web_calls={}
  self.repeated_web_failure=RepeatedWebFailure()
  self.web_basis=WebEvidenceBasis()
  self.progress_parser=SSEProgress(self.policy,self.observe_current_event)
  kw["stream_observer"]=self.observe;super().__init__(*a,**kw)
 def observe_event(self,rid,event):
  self.upstream_delivery.observe(rid,event)
  item=event.get("item") or {}
  if (event.get("type")=="response.output_item.done" and item.get("type")=="function_call"
      and item.get("name") in WEB_NAMES and item.get("call_id")):
   self.emitted_web_calls[item["call_id"]]=item["name"]
   return item
 def observe_current_event(self,rid,event):
  proposal=self.observe_event(rid,event)
  if proposal:
   self.repeated_web_failure.proposed(rid,proposal["call_id"],proposal["name"])
 def observe(self,stage,rid,chunk,metadata):
  self.sink(stage,rid,chunk,metadata)
  if stage!="upstream":return
  self.progress_parser.policy=self.policy
  self.progress_parser.feed(rid,chunk)
 def restore_runtime_context(self,*a,**kw):
  try:return self._restore(*a,**kw)
  except BaseException as exc:
   if not isinstance(exc,StopRequested) and self.first_exception is None:
    self.first_exception={"stage":"provider_history_projection","attempt":self.count,"type":type(exc).__name__,"reason":str(exc)}
    dump(self.out/"first-bridge-exception.json",self.first_exception)
   raise
 def set_compaction(self,turn_id,active):
  with self.phase_change:
   super().set_compaction(turn_id,active)
   self.phase_change.notify_all()
 def synchronized_projection(self,request,*,compact=False):
  # Native lifecycle and HTTP arrive on separate channels. In daily a normal
  # request always has registered tools. An empty list may prompt a wait, but
  # cannot authorize summary mode: only the route or the Host lifecycle can.
  with self.phase_change:
   if not compact:
    expects_compaction=request.get("tools")==[]
    def phase_matches():
     return (self._compaction_turn_id is not None)==expects_compaction
    if not phase_matches():
     timeout=2*P["limits"]["poll_seconds"]
     if not self.phase_change.wait_for(phase_matches,timeout=timeout):
      raise ValueError("Native compaction lifecycle disagrees with outgoing tool catalogue")
   return super().restore_runtime_context(request,compact=compact)
 def _restore(self,*a,**kw):
  self.count+=1
  decision=self.policy.begin_request("provider-"+str(self.count))
  append(self.out/"budget-events.jsonl",{"event":"request_admission","attempt":self.count,"decision":decision.to_dict()})
  if not decision.request_allowed:
   self.budget_stop=decision.to_dict();raise StopRequested(budget_stop_reason(self.budget_stop))
  q,d=self.synchronized_projection(*a,**kw);q=deepcopy(q)
  compact=any(x.get("kind")=="host_context_deferred_for_compaction"for x in d)
  host,_omitted,_size=self._bounded_blocks(self._runtime_context["blocks"])
  expected=json.loads(host["uaea.goal_hypotheses"]["value"])
  source=next((entry for entry in d if entry.get("source")=="published_host_snapshot"),{})
  if self.count==1:dump(self.out/"pre-toggle-first-request.json",q)
  q,proof=prepare_goal_view(q,self.arm,expected_view=expected,compact=compact,current_index=source.get("current_goal_index"))
  proof["source_bindings"]=source.get("native_context_bindings",[])
  proof["expected_view"]=expected
  proof["compact"]=compact
  dump(self.out/f"projection-proof-{self.count}.json",proof)
  if not proof["valid"]:
   raise StopRequested("WIRE_CONDITION_INVALID:"+repr(proof["reasons"]))
  if not compact:
   current_web_notice(q,self.web_specs, resumed=bool(self.web_previous_text), provider=self.web_provider,
                      authority_block=host.get("uaea.semantic_state_projection"),received_at=self.received_at,
                      excluded_providers=self.web_excluded_providers)
   verified_web=self.web_basis.project(q,self.emitted_web_calls)
   project_calendar_literals(q,verified_web)
   if self.first_web_tool:
    if q.get("tool_choice") != "auto":
     raise StopRequested("UNEXPECTED_NATIVE_TOOL_CHOICE")
    if any(t.get("name")==self.first_web_tool for t in q["tools"]):
     q["tool_choice"]={"type":"function","name":self.first_web_tool}
    self.first_web_tool=None
   # React only to a rejection of a proposal emitted in this very turn.
   # Historical unavailable-tool messages stay in place and do not trigger finalization.
   if restrict_repeated_unavailable_web(q,self.emitted_web_calls):
    append(self.out/"budget-events.jsonl",{"event":"final_answer_after_repeated_unavailable_web","attempt":self.count})
   repeated=self.repeated_web_failure.project(q,last_request=decision.request_count==self.policy.config.max_requests)
   if repeated:
    append(self.out/"budget-events.jsonl",{"event":"repeated_web_failure","attempt":self.count,**repeated})
   q["max_output_tokens"]=P["limits"]["output_tokens"]
   assert [x for x in q.get("tools",[])if x.get("name")=="goal_hypothesis"]==[json.loads((B/"actual-prior-tool-definition.json").read_text())],"TOOL_SCHEMA_DRIFT"
  slot=daily_delivery_check.reserve_answer(q,compact=compact,last=decision.request_count==self.policy.config.max_requests)
  if slot:
   self.answer_only=slot=="budget_answer_reserved"
   append(self.out/"budget-events.jsonl",{"event":slot,"attempt":self.count})
  if CPU and compact:
   q["metadata"]={"cpu_input":"","cpu_text":"","phase":self.phase,"attempt":self.count,"mode":"compact"}
  elif CPU:
   txt="\n".join(c.get("text","")for i in q.get("input",[])for c in i.get("content",[])if isinstance(c,dict))
   cur=json.loads(re.findall(r"<external_uaea.current_user_request>(.*?)</external_uaea.current_user_request>",txt,re.S)[-1])
   q["metadata"]={"cpu_input":cur["input_id"],"cpu_text":cur["text"],"phase":self.phase,"attempt":self.count,"mode":CPU_MODE}
  dump(self.out/f"actual-projected-request-{self.count}.json",q)
  return q,d
 def close(self):
  try:super().close()
  finally:self.sink.close()
old.repl.ProviderHistoryBridge=Capture
class ResearchApp(old.ContinuityApp):
 def _turn_lifecycle(self,event):
  super()._turn_lifecycle(event)
  if event == "wait_interrupted":
   # The interactive Harness would return to its control prompt. This research
   # loop owns that prompt, so stop its wait instead of silently polling again.
   raise OperatorInterrupted("Operator interrupted the active turn")
 def _request_turn(self,message,*,timeout):
  self._delivery_request_id=message["id"]
  return super()._request_turn(message,timeout=P["limits"]["poll_seconds"] if not CPU else .1)
 def _send(self,message):
  active=getattr(self,"_handling_call",None)
  if active and "result"in message:
   record={"call_id":active["callId"],"params":deepcopy(active),"result":deepcopy(message["result"]),"host_result_recorded":True,"rpc_send_status":"attempted_not_delivery_proof"}
   append(self.events_path.parent/"host-rpc-results.jsonl",record)
   self._history_bridge.repeated_web_failure.observe(active,message["result"])
   self._history_bridge.web_basis.observe(active,message["result"])
   if not hasattr(self,"_formed_results"):self._formed_results=set()
   self._formed_results.add(active["callId"])
  return super()._send(message)
def make_app(out,store,guard,route):
 root=Path(P["source_root"]);registry=DailyToolRegistry(old.Sandbox(root,root),old.LedgerStub(out/"tool-traces"), fetch_targets=route.fetch_targets)
 binding=old.DynamicToolBinding.from_registry(registry,"document.read_section",
  description="Read a positive 1-based Markdown section ordinal exactly as listed in the returned catalogue. Partial visible content is not full-document review.",
  input_schema={"type":"object","properties":{"path":{"type":"string"},"section_index":{"type":"integer","minimum":1}},"required":["path","section_index"],"additionalProperties":False})
 bindings=[binding]
 current=json.loads((out/"input.json").read_text())["text"]
 names=route.names
 if names:
  old.repl.load_web_environment(report=False)
  source_root=out.parent.parent/"web-sources"
  source_root.mkdir(exist_ok=True)
  web=old.repl.register_web_tools(registry,source_root/"source.sqlite",
      DailyWebAdapter(provider=route.provider,excluded_providers=route.excluded_providers,snapshot_root=source_root/"snapshots",timeout_seconds=20))
  bindings.extend(scoped_web_bindings(web, route))
 grant=json.loads((out/"input.json").read_text()).get("session_web_grant")
 dump(out/"web-access-policy.json",{"enabled":bool(names),"basis":("session_operator_command" if grant else "current_operator_input") if names else "offline","session_web_grant":grant,
      "input_sha256":digest(current.encode()),"tool_names":[b.tool_name for b in bindings]})
 adapter=old.ResearchDocumentAdapter(registry,bindings,max_output_chars=12000)
 url="http://127.0.0.1:18437"if CPU else"http://127.0.0.1:8003"
 old.write_config(out/"codex-home",url,65536,model="nemotron-bolt-n1x",n1x=True)
 app=ResearchApp(continuity=store,codex=old.repl.DEFAULT_CODEX_BIN,codex_home=out/"codex-home",workspace=root,
  base_url=url,adapter=adapter,events_path=out/"app-server-events.jsonl",stderr_path=out/"stderr.log",
  turn_timeout=P["limits"]["hard_seconds"],model="nemotron-bolt-n1x",reasoning_effort="none",
  execution_contract="shared",goal_mode="shadow",goal_projection="optional",input_actor="test_driver")
 app.adapter.execution_boundary=TurnReadOnlyHost(registry,app.adapter.execution_boundary.semantic,
       app.adapter.execution_boundary.journal_path)
 app.adapter.execution_boundary.CAPABILITIES=tuple(b.capability for b in bindings)
 app.research_fixture_files=[{"path":str(root/"index.md"),"available_since_turn":"same frozen catalogue; existence is not reading"}]
 return app
def call_cache(source):
 return build_call_cache(rows(source/"app-server-events.jsonl"),rows(source/"host-rpc-results.jsonl"))

def snapshot(app,store,out,label):
 """Atomic manifest published after a coherent event-boundary Host snapshot. Active is diagnostic only."""
 generations=out/"checkpoints";generations.mkdir(exist_ok=True)
 n=len(list(generations.glob("g*")));gen=generations/f"g{n:04d}";gen.mkdir()
 for h in [getattr(app,"_events_file",None),getattr(app,"_stderr_file",None)]:
  if h and not h.closed:h.flush()
 state=app.semantic_state.delegate._state_for(app.thread_id)
 (gen/"host-state.pickle").write_bytes(pickle.dumps(state))
 (gen/"normalizer.pickle").write_bytes(pickle.dumps(app.semantic_state.delegate.normalizer))
 dump(gen/"semantic-calls.json",sorted(app.semantic_state.semantic_calls))
 dump(gen/"after-state.json",{"heads":store.heads(app.thread_id),"versions":list(store.versions.values()),"view":store.view(app.thread_id),"snapshot":app.semantic_state.snapshot(app.thread_id)})
 shutil.copyfile(store.path,gen/"goal-journal.jsonl")
 cursors={}
 for name in ["app-server-events.jsonl","host-rpc-results.jsonl","execution-contract.trajectory.jsonl","model-http-audit.jsonl"]:
  p=out/name
  if p.exists():
   raw=p.read_bytes();cursors[name]={"bytes":len(raw),"prefix_sha256":digest(raw)}
 manifest={"label":label,"thread":app.thread_id,"pending_turn":deepcopy(app._pending_turn),"resume_eligible":False,
  "reason":"active/boundary Host snapshot only; Native process not sealed","event_prefixes":cursors,
  "files":{p.name:digest(p.read_bytes())for p in gen.iterdir()if p.is_file()}}
 dump(gen/"manifest.json",manifest);dump(out/"latest-checkpoint.json",{"generation":str(gen),"manifest_sha256":digest((gen/"manifest.json").read_bytes())})
 return gen
def seal(app,store,out,terminal_confirmed,reason):
 gen=snapshot(app,store,out,"closed-"+reason)
 for name in ["host-state.pickle","normalizer.pickle","semantic-calls.json","after-state.json"]:
  shutil.copyfile(gen/name,out/name)
 # No Native copy while process is alive; out/codex-home is closed by caller first.
 if terminal_confirmed and reason=="completed":
  all_inputs=[obj.to_dict() for obj in app.semantic_state.delegate._state_for(app.thread_id).runtime_objects.objects if obj.object_type=="workflow_request_input"]
  count=verify_input_bindings(out/"app-server-events.jsonl",app.thread_id,all_inputs,full_state=True)
  dump(out/"registered-input-bindings.json",{"checked_registered_inputs":count,"native_event":"item/completed userMessage","thread":app.thread_id,"matched":True})
 sealed=B/"sealed"/(CPU_RUN_NAME if CPU else"live")/out.parent.name/out.name
 sealed.mkdir(parents=True,exist_ok=False)
 if terminal_confirmed:
  dump(sealed/"native-copy-proof.json",old.clone_native_home(out,sealed/"codex-home",app.thread_id))
  complete_cache=all("result"in v for v in call_cache(out).values())
 else:complete_cache=False
 dump(out/"resume-manifest.json",{"terminal_confirmed":terminal_confirmed,"resume_eligible":terminal_confirmed and complete_cache,
  "thread":app.thread_id,"native_home":str(sealed/"codex-home")if terminal_confirmed else None,
  "host_generation":str(gen),"stop_reason":reason,"historical_call_cache_complete":complete_cache,
  "scope":"research-only; explicit successor may start a new Native Turn, never re-execute old calls"})
 return terminal_confirmed and complete_cache
def run_from(source,out,text,guard,mode=None,*,terminal_web=False,session_web=None):
 global ACTIVE,POLICY,CPU_MODE
 route=WebRoute(frozenset()) if CPU else web_route(text,Path(source) if source else None,terminal_web=terminal_web,session_web=session_web)
 if route.basis=="await_topic":raise ValueError("Standalone /web needs a search topic")
 ACTIVE=out;CPU_MODE=mode
 out.mkdir(parents=True,exist_ok=False)
 dump(out/"input.json",{"text":text,"received_at":datetime.now().astimezone().isoformat(timespec="seconds"),"terminal_command":"/web" if terminal_web else None,"session_web_grant":session_web,"researcher_authored":INPUT_ORIGIN!="operator_supplied","origin":INPUT_ORIGIN,"phase":PHASE})
 dump(out/"human-origin.json",{"actor":"operator","input_kind":"natural_user_entry" if INPUT_ORIGIN=="operator_supplied" else INPUT_ORIGIN,"fixture":INPUT_ORIGIN!="operator_supplied","profile":str(out.parent.parent)})
 fresh=source is None
 if fresh:
  profile=out/"profile"
  thread=None
  cached={}
 else:
  source=Path(source)
  original=json.loads((source/"result.json").read_text());thread=original["thread"]
  if (source/"resume-manifest.json").exists():
   rm=json.loads((source/"resume-manifest.json").read_text());assert rm["resume_eligible"]
  else:assert original["terminal"]=="completed"
  assert json.loads((source/"cleanup.json").read_text())["process_group_state"]=="absent"
  if (source/"resume-manifest.json").exists():
   generation=Path(rm["host_generation"]);manifest=json.loads((generation/"manifest.json").read_text())
   for name,expected_hash in manifest["files"].items():
    assert digest((generation/name).read_bytes())==expected_hash,"CHECKPOINT_GENERATION_CORRUPT"
   for name in ["host-state.pickle","normalizer.pickle","semantic-calls.json","after-state.json"]:
    assert (source/name).read_bytes()==(generation/name).read_bytes(),"CHECKPOINT_ROOT_DIFFERS_FROM_GENERATION"
   assert (source/"profile/goal-journal.jsonl").read_bytes()==(generation/"goal-journal.jsonl").read_bytes(),"CHECKPOINT_JOURNAL_DIFFERS"
   for name,cursor in manifest["event_prefixes"].items():
    assert digest((source/name).read_bytes()[:cursor["bytes"]])==cursor["prefix_sha256"],"CHECKPOINT_EVENT_PREFIX_CHANGED"
 
  existing=json.loads((source/"after-state.json").read_text())["snapshot"]
  verify_input_bindings(source/"app-server-events.jsonl",thread,existing["workflow_continuity"]["request_continuity"]["inputs"])
  profile=out/"profile";profile.mkdir();shutil.copyfile(source/"profile/goal-journal.jsonl",profile/"goal-journal.jsonl")
  # A stopped source uses the sealed, closed Native home; other files remain immutable original records.
  native_source=source
  if (source/"resume-manifest.json").exists():
   rm=json.loads((source/"resume-manifest.json").read_text())
   native_source=Path(rm["native_home"]).parent
  dump(out/"native-copy-proof.json",old.clone_native_home(native_source,out/"codex-home",thread))
  for name in ["app-server-events.jsonl","execution-contract.trajectory.jsonl","host-rpc-results.jsonl"]:
   if(source/name).exists():shutil.copyfile(source/name,out/name)
  state=(source/"host-state.pickle").read_bytes();norm=(source/"normalizer.pickle").read_bytes()
  sem=set(json.loads((source/"semantic-calls.json").read_text()));expected=json.loads((source/"after-state.json").read_text())["snapshot"]
  cached=call_cache(source)
 limits=P["limits"]if mode!="stop"else{"soft_seconds":.2,"hard_seconds":1.5,"idle_seconds":1.0,"provider_requests_per_turn":6}
 POLICY=BudgetPolicy(BudgetConfig(soft_seconds=limits["soft_seconds"],hard_seconds=limits["hard_seconds"],no_progress_seconds=limits["idle_seconds"],max_requests=limits["provider_requests_per_turn"]))
 with old.ContinuityJournal(profile,create=fresh)as store:
  app=make_app(out,store,guard,route);handler=app._handle_tool_call;loading=[True];restored=False;terminal=False;reason="execution_failure";initial_n=0
  def guarded(message):
   params=message.get("params",{});cid=params.get("callId")
   if cid in cached:
    entry=cached[cid];assert all(params.get(k)==entry["params"].get(k)for k in ["threadId","turnId","tool","arguments"]),"HISTORICAL_CALL_IDENTITY_CONFLICT"
    if "result"not in entry:raise StopRequested("HISTORICAL_CALL_WITHOUT_RESULT_NO_REEXECUTION")
    append(out/"historical-rpc-reuse.jsonl",{"call_id":cid,"new_execution":False,"delivery_status":"cached_reply_not_model_delivery_proof"})
    app._send({"jsonrpc":"2.0","id":message["id"],"result":deepcopy(entry["result"])});return
   if loading[0]:raise StopRequested("NEW_TOOL_DURING_RESTORE_FORBIDDEN")
   guard_check(guard)
   decision=POLICY.evaluate()
   if decision.action=="stop":raise StopRequested(decision.reason)
   app._handling_call=params
   try:
    if app._history_bridge.answer_only:
     app._send({"jsonrpc":"2.0","id":message["id"],"result":{"success":False,"contentItems":[{"type":"inputText","text":"Budget closeout: no new operation executed."}]}})
     return
    return handler(message)
   finally:
    app._handling_call=None
    if cid in getattr(app,"_formed_results",set()):POLICY.note_progress("tool_result",cid,{"host_formed_result":True})
    snapshot(app,store,out,"after-host-call")
  consume=isolated_input_consumer(app,app.semantic_state.consume_raw_event);app.semantic_state.consume_raw_event=lambda *a,**k:[]
  app._handle_tool_call=guarded
  try:
   if not fresh:stage_resume_catalogue(out,thread,app.adapter.dynamic_tools(),dump)
   guard_check(guard);app.start(resume_thread_id=thread);app.semantic_state.consume_raw_event=consume
   app._history_bridge.web_specs=app.adapter.dynamic_tools()
   app._history_bridge.web_previous_text=route.previous_text
   app._history_bridge.web_provider=route.provider
   app._history_bridge.web_excluded_providers=route.excluded_providers
   app._history_bridge.first_web_tool=route.first_tool
   dump(out/"web-request-routing.json",{"first_tool":route.first_tool,"basis":route.basis,
       "provider":route.provider,"previous_turn":original["turn"] if route.previous_text else None})
   if fresh: thread=app.thread_id
   assert app.thread_id==thread
   assert not any(e.get("event")=="request_prepared"for e in rows(out/"model-http-audit.jsonl"))
   if not fresh:
    app.semantic_state.delegate._states[thread]=pickle.loads(state);app.semantic_state.delegate.normalizer=pickle.loads(norm)
    app.semantic_state.semantic_calls=deepcopy(sem)
    app.adapter.execution_boundary._sequence=max((x["sequence"]for x in rows(out/"execution-contract.trajectory.jsonl")),default=0)
    historical_inputs=[obj.to_dict() for obj in app.semantic_state.delegate._state_for(thread).runtime_objects.objects if obj.object_type=="workflow_request_input"]
    verify_input_bindings(out/"app-server-events.jsonl",thread,historical_inputs,full_state=True)
    assert app.semantic_state.snapshot(thread)==expected
    assert old.plain(app.semantic_state.delegate._state_for(thread))==old.plain(pickle.loads(state))
    assert not app.adapter.execution_boundary._boundaries
    assert store.path.read_bytes()==(source/"profile/goal-journal.jsonl").read_bytes()
   restored=True;loading[0]=False;snapshot(app,store,out,"restored-before-input")
   dump(out/"restore-proof.json",{"fresh":fresh,"source":str(source),"thread":thread,"full_Host_state_equal":not fresh,"normalizer_restored":not fresh,"Journal_bytes_equal":not fresh,"new_model_requests_during_restore":0,"new_tool_dispatches_during_restore":0,"historical_cache_entries":len(cached),"new_process":True,"original_process_absent":True})
   initial_n=len(rows(out/"app-server-events.jsonl"));start=time.monotonic()

   POLICY=BudgetPolicy(BudgetConfig(soft_seconds=limits["soft_seconds"],hard_seconds=limits["hard_seconds"],no_progress_seconds=limits["idle_seconds"],max_requests=limits["provider_requests_per_turn"]))
   app._history_bridge.policy=POLICY
   app.run_turn(text)
   while app._pending_turn is not None:
    guard_check(guard)
    if app.process.poll()is not None:raise StopRequested("HARNESS_PROCESS_EXIT")
    if app._history_bridge.first_exception:raise StopRequested("BRIDGE_EXECUTION_FAILURE:"+json.dumps(app._history_bridge.first_exception,ensure_ascii=False))
    if app._history_bridge.budget_stop:raise StopRequested(budget_stop_reason(app._history_bridge.budget_stop))
    decision=POLICY.evaluate()
    append(out/"budget-events.jsonl",{"event":"wait_boundary","decision":decision.to_dict(),"pending":deepcopy(app._pending_turn)})
    snapshot(app,store,out,"wait-boundary")
    if decision.action=="stop":raise StopRequested(decision.reason)
    app._resume_pending_turn(timeout=P["limits"]["poll_seconds"]if not CPU else .1,journal_unconfirmed=False)
   tail=[x["message"]for x in rows(out/"app-server-events.jsonl")[initial_n:]if"message"in x]
   target_turn=started_turn_id(tail,app._delivery_request_id)
   delivery=checked_delivery(tail,thread,target_turn)
   requests=[e["request_id"] for e in rows(out/"model-http-audit.jsonl") if e.get("event")=="request_prepared"]
   request_id=requests[-1] if requests and len(requests)==app._history_bridge.count else None
   delivery=app._history_bridge.upstream_delivery.classify(delivery,request_id)
   delivery=daily_delivery_check.classified_delivery(out,delivery,app._history_bridge.count)
   terminal=delivery["terminal_confirmed"]
   native={"id":target_turn,"status":delivery["native_status"]}
   answers=delivery["answers"]
   completed=delivery["delivery_complete"]
   reason="completed"if completed else("task_incomplete"if native.get("status")=="completed"else"execution_failure")
   if delivery.get("reason")==daily_delivery_check.STAGE:reason="stage_answer"
   result={"thread":thread,"turn":native.get("id"),"terminal":native.get("status","unconfirmed"),"classification":reason,"seconds":time.monotonic()-start,"answers":answers,"delivery_validation":delivery,
    "new_calls":[e["params"]["item"]for e in tail if e.get("method")=="item/completed"and e["params"]["item"].get("type")=="dynamicToolCall"],"provider_requests":app._history_bridge.count,"arm":ARM,"phase":PHASE}
   if delivery.get("reason") in (daily_delivery_check.STAGE,daily_delivery_check.REASON):result["reason"]=delivery["reason"]
   if completed:POLICY.evaluate(completed=True)
   if completed and getattr(app, "controlled_compaction", False):
    from research.longitudinal_dialogue import compact_existing_thread
    guard_check(guard)
    # This optional research-only compact command starts a separate Native Turn.
    # Preserve the user's terminal budget and give the control its normal limits.
    dump(out/"user-turn-budget.json",POLICY.snapshot())
    POLICY=BudgetPolicy(BudgetConfig(soft_seconds=limits["soft_seconds"],hard_seconds=limits["hard_seconds"],no_progress_seconds=limits["idle_seconds"],max_requests=limits["provider_requests_per_turn"]))
    app._history_bridge.policy=POLICY
    compact_existing_thread(app,out,1)
    result["provider_requests_with_compact"]=app._history_bridge.count
   dump(out/"result.json",result)
   return result
  except BaseException as exc:
   text_reason=str(exc)or type(exc).__name__
   classification="external_interrupt"if isinstance(exc,(OperatorInterrupted,KeyboardInterrupt,SystemExit))else("budget_stop"if any(x in text_reason.lower()for x in ["budget","hard","idle","no_progress","soft"])else("resource_stop"if "RESOURCE"in text_reason or "Guard"in text_reason else"execution_failure"))
   reason=text_reason
   if restored:snapshot(app,store,out,"before-stop")
   if app._pending_turn is not None:
    append(out/"budget-events.jsonl",{"event":"interrupt_existing_turn","reason":reason,"pending":deepcopy(app._pending_turn)})
    try:app._control_turn("/turn cancel")
    except Exception as stop_exc:dump(out/"interrupt-error.json",{"type":type(stop_exc).__name__,"reason":str(stop_exc)})
    terminal=app._pending_turn is None
   result={"thread":thread,"terminal":"interrupted"if terminal else"unconfirmed","classification":classification,"reason":reason,"error_type":type(exc).__name__,"answers":[],"arm":ARM,"phase":PHASE,"no_retry":True}
   dump(out/"result.json",result);dump(out/"failure.json",result)
   if classification=="resource_stop":raise
   return result
  finally:
   app.semantic_state.consume_raw_event=consume
   dump(out/"budget-policy-final.json",POLICY.snapshot())
   if restored:snapshot(app,store,out,"last-event-boundary")
   cleanup=old.close_with_receipt(app,None,None);dump(out/"cleanup.json",cleanup)
   if restored and cleanup["process_group_state"]=="absent":seal(app,store,out,terminal,reason)
def cpu_server():
 from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
 class Handler(BaseHTTPRequestHandler):
  def log_message(self,*a):pass
  def do_POST(self):
   q=json.loads(self.rfile.read(int(self.headers["Content-Length"])));m=q["metadata"];tag=uuid.uuid4().hex
   events=[{"type":"response.created","response":{"id":"cpu-"+tag}}]
   mode=m["mode"]
   if mode=="stop"and m["attempt"]==2:
    self.send_response(200);self.send_header("Content-Type","text/event-stream");self.end_headers()
    try:
     self.wfile.write(("data: "+json.dumps(events[0])+"\n\n").encode());self.wfile.flush()
     for i in range(100):
      e={"type":"response.output_text.delta","item_id":"cpu-text","output_index":0,"content_index":0,"delta":"x","sequence_number":i+1}
      self.wfile.write(("data: "+json.dumps(e)+"\n\n").encode());self.wfile.flush();time.sleep(.05)
    except (BrokenPipeError,ConnectionResetError):pass
    return
   call=None
   if m["attempt"]==1 and mode!="compact":
    call=("goal_hypothesis",{"operation":"form","candidate_id":None,"hypothesis":"CPU fixture only: investigate local continuity protocol.","quote":m["cpu_text"],"input_ids":[m["cpu_input"]],"evidence_ids":[]}) if mode=="form_fixture" else ("read_section",{"path":str(Path(P["source_root"])/"index.md"),"section_index":1})
   if call:
    events.append({"type":"response.output_item.done","output_index":0,"item":{"type":"function_call","id":"item-"+tag,"call_id":"cpu-"+tag,"name":call[0],"arguments":json.dumps(call[1],ensure_ascii=False)}})
   else:events.append({"type":"response.output_item.done","output_index":0,"item":{"type":"message","role":"assistant","id":"msg-"+tag,"status":"completed","content":[{"type":"output_text","text":"CPU protocol only; not cognitive evidence."}]}})
   events.append({"type":"response.completed","response":{"id":"cpu-"+tag,"status":"completed","incomplete_details":None,"usage":{"input_tokens":1000,"output_tokens":20,"total_tokens":1020}}})
   raw="".join("data: "+json.dumps(x,ensure_ascii=False)+"\n\n"for x in events).encode()
   self.send_response(200);self.send_header("Content-Type","text/event-stream");self.send_header("Content-Length",str(len(raw)));self.end_headers();self.wfile.write(raw)
 server=ThreadingHTTPServer(("127.0.0.1",18437),Handler);threading.Thread(target=server.serve_forever,daemon=True).start();return server
