"""Research-entry binding of registered user input to the Native user message that supplied it."""
import hashlib
import json


def _user_tuple(params):
    item = params["item"]
    # The daily CLI sends one text item. A new Native content protocol needs review.
    parts = item["content"]
    if len(parts) != 1 or parts[0].get("type") != "text" or not isinstance(parts[0].get("text"), str):
        raise ValueError("Unsupported Native user message content")
    return (params["threadId"], params["turnId"], hashlib.sha256(parts[0]["text"].encode()).hexdigest())


def verify_input_bindings(native_log, thread_id, inputs, *, full_state=False):
    """Join by Native item ID, then check its actual Turn and user text. No repair or guessing."""
    native = {}
    with native_log.open(encoding="utf-8") as stream:
        for line in stream:
            message = json.loads(line).get("message", {})
            params = message.get("params") or {}
            item = params.get("item") or {}
            if (message.get("method") != "item/completed" or item.get("type") != "userMessage"
                    or params.get("threadId") != thread_id):
                continue
            key = item["id"]
            value = _user_tuple(params)
            if key in native and native[key] != value:
                raise ValueError("Conflicting Native user message identity")
            native[key] = value
    seen = set()
    for record in inputs:
        meta = record["metadata"]
        origin = meta.get("host_input_origin", {})
        if origin.get("channel") != "registered_user_entry":
            raise ValueError("Missing registered user source")
        provenance = meta["provenance"]
        key = provenance.get("item_id")
        raw_hash = hashlib.sha256(meta["text"].encode()).hexdigest()
        if (key in seen or key not in native
                or origin.get("input_id") != record["object_id"]
                or meta.get("input_id") != record["object_id"]
                or provenance.get("input_id") != record["object_id"]
                or origin.get("raw_text_sha256") != raw_hash or meta.get("raw_text_sha256") != raw_hash
                or provenance.get("thread_id") != thread_id
                or native[key] != (thread_id, provenance.get("turn_id"), raw_hash)):
            raise ValueError("Registered input disagrees with Native user message: " + record["object_id"])
        seen.add(key)
    if full_state and seen != set(native):
        raise ValueError("Native user message missing from restored Host inputs")
    return len(seen)


def isolated_input_consumer(app, consume):
    """A prepared registration belongs to exactly one user Turn. Still consume control events."""
    bound = None

    def receive(raw, **kwargs):
        nonlocal bound
        msg = raw.get("message", {})
        p = msg.get("params") or {}
        if p.get("threadId") != app.thread_id or not p.get("threadId"):
            return consume(raw, **kwargs)
        turn = p.get("turnId") or (p.get("turn") or {}).get("id")
        state = app.semantic_state.delegate._state_for(app.thread_id)
        matches = bound is not None and state.current_input_id == bound[0]
        if matches and turn and turn != bound[1] and state.prepared_input_applied:
            # A separate control turn can interleave after the user item and before
            # the user's terminal event. Let Host consume it without rebinding input.
            saved = (state.prepared_input_applied, state.pending_user_input, state.pending_turn_id)
            state.prepared_input_applied, state.pending_user_input, state.pending_turn_id = False, "", ""
            try:
                return consume(raw, **kwargs)
            finally:
                state.prepared_input_applied, state.pending_user_input, state.pending_turn_id = saved
        result = consume(raw, **kwargs)
        item = p.get("item") or {}
        if msg.get("method") == "item/completed" and item.get("type") == "userMessage":
            if state.prepared_input_applied and state.pending_turn_id == turn:
                bound = (state.current_input_id, turn)
        elif (msg.get("method") == "turn/completed" and matches and turn == bound[1]):
            # Keep normal same-user-turn binding through its actual terminal event.
            state.prepared_input_applied, state.pending_user_input, state.pending_turn_id = False, "", ""
        return result

    return receive
