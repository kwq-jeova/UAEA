from pathlib import Path
import sys,json,subprocess,fcntl
B=Path(__file__).resolve().parent
sys.path.insert(0,str(B));import pilot
def j(p):return json.loads(p.read_text())
def rows(p):return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]
proof={"scope":"CPU fake endpoint + real Native 0.170 protocol; no natural cognitive claim","checks":{}}
def ck(name,value):
 assert value,name
 proof["checks"][name]=True
home=B/"cpu-profiles/goalform170";runs=sorted((home/"runs").glob("*"));ck("two_separate_process_runs",len(runs)==2)
r1,r2=runs
for r in runs:
 m=j(r/"run-manifest.json");res=j(r/"result.json")
 ck(r.name+"_operator_actual_bound_actor",m["input_actor"]=="operator")
 ck(r.name+"_cpu_origin_explicit",j(r/"input.json")["researcher_authored"] is True and j(r/"input.json")["origin"]=="cpu_fixture")
 ck(r.name+"_complete",res["delivery_validation"]["delivery_complete"] is True)
 ck(r.name+"_resume_sealed",j(r/"resume-manifest.json")["resume_eligible"] is True)
 ck(r.name+"_native_closed",j(r/"cleanup.json")["process_group_state"]=="absent")
 v=rows(r/"harness-versions.jsonl")[0];ck(r.name+"_170_real_binary",v["reported_version"]=="codex-cli 0.170.0" and v["untrusted_as_tool_output"] is False)
 for f in r.glob("projection-proof-*.json"):ck(r.name+"_"+f.stem,j(f)["valid"] is True)
 for f in r.glob("actual-projected-request-*.json"):
  q=j(f);tx=json.dumps(q,ensure_ascii=False)
  ck(r.name+"_"+f.stem+"_no_sim_fixture","external_uaea.research_fixture" not in tx)
  ck(r.name+"_"+f.stem+"_no_permission_prompt",pilot.study.P["permission_clarification"] not in tx)
  ck(r.name+"_"+f.stem+"_correct_workspace",str(home/"workspace") in tx)
 ck(r.name+"_one_goal_version",len(j(r/"after-state.json")["versions"])==1)
first=j(r1/"after-state.json");last=j(r2/"after-state.json")
ck("head_exactly_preserved",first["heads"]==last["heads"])
restore=j(r2/"restore-proof.json")
for k in ["full_Host_state_equal","normalizer_restored","Journal_bytes_equal","new_process","original_process_absent"]:ck("restore_"+k,restore[k] is True)
ck("no_historical_tool_redispatch",restore["new_tool_dispatches_during_restore"]==0)
ck("no_model_request_during_restore",restore["new_model_requests_during_restore"]==0)
ck("same_native_thread",j(r1/"result.json")["thread"]==j(r2/"result.json")["thread"])
expected=first["heads"][0]["metadata"]["hypothesis"]["hypothesis"]
view=j(r2/"projection-proof-1.json")["expected_view"]
ck("persisted_head_in_successor_goal_view",any(x["candidate_id"]==first["heads"][0]["object_id"] for x in view["heads"]))
ck("persisted_hypothesis_actually_sent",expected in json.dumps(j(r2/"actual-projected-request-1.json"),ensure_ascii=False))
q2=json.dumps(j(r2/"actual-projected-request-1.json"),ensure_ascii=False)
ck("prior_input_and_final_answer_visible", "CPU fixture only: I want to investigate local continuity protocol." in q2 and "CPU protocol only; not cognitive evidence." in q2)
journal=rows(r1/"profile/goal-journal.jsonl")
event=next(x["payload"]["event"] for x in journal if x["kind"]=="EVENT")
ck("CPU_constructed_call_committed",event["payload"]["receipt"]["committed"] is True)
ck("no_authority_promotion",event["payload"]["receipt"]["active_goal_changed"] is False and event["payload"]["receipt"]["authorizes_action"] is False)
sandbox=pilot.study.old.Sandbox(home/"workspace",home/"workspace")
refused=[]
for path in [str(r1/"profile/goal-journal.jsonl"),str(home/"latest.json"),"../latest.json",str(B/"sealed")]:
 try:sandbox.read_path(path)
 except Exception as e:refused.append({"path":path,"reason":type(e).__name__})
ck("sandbox_blocks_journal_profile_parent_sealed",len(refused)==4)
proof["sandbox_refusals"]=refused
lock=(home/"session.lock").open("a+");fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
rr=subprocess.run([sys.executable,str(B/"pilot.py"),"--profile","goalform170","--cpu-fixture"],input="/quit\n",text=True,capture_output=True,timeout=10)
fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
ck("concurrent_profile_refused",rr.returncode!=0 and "already in use" in rr.stderr)
blocked=B/"cpu-profiles/blocked-probe";blocked.mkdir(parents=True,exist_ok=True);(blocked/"needs-review.json").write_text('{"reason":"CPU intentional interruption latch"}')
rr=subprocess.run([sys.executable,str(B/"pilot.py"),"--profile","blocked-probe","--cpu-fixture"],input="/quit\n",text=True,capture_output=True,timeout=10)
ck("interrupted_profile_blocks_silent_rollback",rr.returncode!=0 and "blocked for review" in rr.stderr)
rr=subprocess.run([sys.executable,str(B/"pilot.py"),"--profile","quit-probe","--cpu-fixture"],input="/quit\n",text=True,capture_output=True,timeout=10)
ck("quit_without_turn",rr.returncode==0 and not (B/"cpu-profiles/quit-probe/latest.json").exists())
try:pilot.owned_guard(Path("/home/wqkan_wsl/uaea-n1x/nemotron-bolt/records/manual-20261119T001647Z-369b0662"))
except Exception as e:guard_error=str(e)
else:guard_error=""
ck("stopped_guard_refused",bool(guard_error))
proof["stopped_guard_reason"]=guard_error
ck("real_profile_never_created",not (B/"real-user").exists())
proof["candidate_id"]=first["heads"][0]["object_id"];proof["native_thread"]=j(r2/"result.json")["thread"]
proof["new_natural_user_turns"]=0
proof["new_gpu_model_requests"]=0
proof["runs"]=[str(r) for r in runs]
(B/"cpu-proof-final.json").write_text(json.dumps(proof,ensure_ascii=False,indent=2))
print(json.dumps({"checks_passed":len(proof["checks"]),"candidate_id":proof["candidate_id"],"thread":proof["native_thread"]},ensure_ascii=False))
