"""Isolated real-user research wrapper. No model service launch or history import."""
from pathlib import Path
from daily_delivery_check import REASON as TEXT_ONLY, STAGE
import argparse,json,os,sys,time,uuid
os.umask(0o077)
B=Path(__file__).resolve().parent
sys.path.insert(0,str(B))
import study
from daily_source_calendar import calendar_notice
from daily_web import command_body, revokes_session_web, web_activity, web_route
from entry_helpers import previous, reviewed_budget_source, verify_native_origin
from terminal_input import line_reader, utf8_terminal_erase, validate_input_text
from research.check_checkpoint import inspect as inspect_checkpoint
BINARY=Path("/home/wqkan_wsl/uaea-n1x/research-records/harness-170-m3-20261118-v1/release/bin/codex")
original_init=study.ResearchApp.__init__
def operator_init(self,**kw):
 kw["input_actor"]="operator"
 original_init(self,**kw)
 self.goals.input_actor="operator"
study.ResearchApp.__init__=operator_init
# Do not project the inherited ScenarioApp SIM fixture into natural user sessions.
def publish_natural(self):
 from copy import deepcopy
 study.old.repl.InteractiveAppServer._publish_runtime_context_snapshot(self)
 bridge=self._history_bridge
 if bridge is None or bridge._runtime_context is None:return
 state=deepcopy(bridge._runtime_context);key="uaea.runtime_facts.filesystem"
 correct={"kind":"application","value":f"Daily read_section resolves relative paths under {self.workspace}. Use the file named in the current request or a verified source path. Only the returned section is evidence of a read."}
 state["blocks"][key]=correct
 if self._last_turn_context is not None:self._last_turn_context[key]=correct
 bridge.set_runtime_context(state["blocks"],thread_id=self.thread_id,input_id=state["input_id"])
study.ResearchApp._publish_runtime_context_snapshot=publish_natural
def owned_guard(guard):
 if guard is None:return
 try:
  _verify_owned_guard(guard)
 except (OSError,ValueError,TypeError,KeyError,RuntimeError) as exc:
  raise study.StopRequested("RESOURCE_GUARD: "+str(exc)) from exc

def _verify_owned_guard(guard):
 study.old.check_guard(guard)
 if (guard/"monitor-exception.json").exists():raise RuntimeError("guard monitor exception")
 policy=json.loads((guard/"run-policy.json").read_text())
 if policy.get("telemetry_protocol")!="single_clock_v1":raise RuntimeError("unverified telemetry protocol")
 manifest=json.loads((guard/"service/manifest.json").read_text())
 ready=json.loads((guard/"service/ready.json").read_text())
 if ready.get("url")!="http://127.0.0.1:8003" or ready.get("model")!="nemotron-bolt-n1x" or ready.get("context")!=65536:raise RuntimeError("wrong guarded service")
 os.kill(manifest["supervisor"],0)
 if Path("/proc/"+str(manifest["pgid"])+"/stat").read_text().split()[21]!=str(manifest["starttime"]):raise RuntimeError("service process identity changed")
 heart=guard/"service/heartbeat-status.json"
 initial=json.loads(heart.read_text())["seq"];begin=time.monotonic()
 while time.monotonic()-begin<3:
  current=json.loads(heart.read_text())
  if current["seq"]>initial and 0<=current["age_monotonic"]<=3:
   host=json.loads((guard/"host-metrics.json").read_text())
   linux=json.loads((guard/"linux-metrics.json").read_text())
   if host.get("run_id")==manifest["run_id"]==linux.get("guard_run_id") and host.get("valid") is True and linux.get("valid") is True:
    study.old.check_guard(guard);return
   raise RuntimeError("guard run/telemetry identity invalid")
  time.sleep(.05)
 raise RuntimeError("guard heartbeat did not advance within 3 seconds")
study.guard_check=owned_guard
study.old.repl.DEFAULT_CODEX_BIN=BINARY
def auto_guard():
 root=Path("/home/wqkan_wsl/uaea-n1x/nemotron-bolt/records")
 candidates=[]
 for ready in root.glob("*/service/ready.json"):
  g=ready.parent.parent
  try:
   state=json.loads((g/"service/state.json").read_text()) if (g/"service/state.json").exists() else {}
   m=json.loads((g/"service/manifest.json").read_text())
   if state.get("done") is True or (g/"monitor-exception.json").exists():continue
   os.kill(m["supervisor"],0)
   candidates.append(g)
  except (OSError,ValueError,KeyError):continue
 if len(candidates)!=1:raise RuntimeError("Expected one live guarded service, found "+str(len(candidates))+"; no model started")
 return candidates[0]
def classify_turn_outcome(result,resume):
 """A sealed Native state can be recoverable without being a completed user delivery."""
 recoverable=resume.get("resume_eligible") is True
 delivery=result.get("delivery_validation",{})
 completed=(result.get("classification")=="completed" and
            delivery.get("delivery_complete") is True and
            delivery.get("terminal_confirmed") is True and
            result.get("terminal")=="completed")
 return {"state_recoverable":recoverable,"delivery_complete":completed,
         "advance_allowed":recoverable and completed,
         "classification":result.get("classification","unknown"),
         "stop_reason":result.get("reason",resume.get("stop_reason","unknown")),
         "policy":"No automatic continuation after incomplete delivery, budget stop, execution/resource failure or external interruption; retain attempt and require review."}
def record_outcome(out,blocked,result,resume,problem=None):
 outcome=classify_turn_outcome(result,resume)
 if problem is None and outcome["advance_allowed"]:
  try:
   inspect_checkpoint(out)
   verify_native_origin(out)
  except (OSError,ValueError,KeyError,TypeError) as exc:
   problem=exc
 if problem is not None:
  outcome.update(advance_allowed=False,state_recoverable=False,
                 entry_error=type(problem).__name__,entry_error_detail=str(problem))
 study.dump(out/"entry-outcome.json",outcome)
 if not outcome["advance_allowed"]:
  study.dump(blocked,{"attempt":str(out),"reason":"Recovery or delivery requires review",**outcome})
  status="本轮完整答复已记录，续接封存未通过" if outcome["delivery_complete"] else "本轮未证实完整交付"
  if outcome["classification"]=="stage_answer":status="本轮已收到阶段答复，整体完成情况未确认"
  print(status+"；状态可恢复="+str(outcome["state_recoverable"])+"。现场已保留。",flush=True)
 return outcome

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument("--profile",default="default")
 p.add_argument("--guard",type=Path)
 p.add_argument("--input-file",type=Path)
 modes=p.add_mutually_exclusive_group()
 modes.add_argument("--cpu-fixture",action="store_true")
 modes.add_argument("--rehearsal",action="store_true",help="Real local model, isolated researcher-authored acceptance profile")
 p.add_argument("--cpu-form-fixture",action="store_true",help=argparse.SUPPRESS)
 a=p.parse_args()
 if a.cpu_form_fixture and not a.cpu_fixture:p.error("form fixture is CPU-only")
 if not a.profile.replace("-","").replace("_","").isalnum():p.error("simple profile name required")
 home=B/("cpu-profiles" if a.cpu_fixture else "rehearsal-profiles" if a.rehearsal else "real-user")/a.profile
 home.mkdir(parents=True,exist_ok=True)
 import fcntl
 lock=(home/"session.lock").open("a+")
 try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 except BlockingIOError:raise SystemExit("This profile is already in use.")
 def review_stopped_turn():
  if a.input_file:
   raise SystemExit("上轮未完成。请从交互窗口核对现场并输入下一条请求。")
  try:
   source=reviewed_budget_source(home,inspect_checkpoint)
  except (OSError,ValueError,KeyError,TypeError) as exc:
   raise SystemExit("现场尚未安全核实，已保留原记录，请检查："+str(exc)) from exc
  previous_reason=json.loads((source/"result.json").read_text()).get("reason")
  text_only=previous_reason==TEXT_ONLY
  explanation="上一轮答复末尾留下了没有执行的网页调用。已有文字已保留，未确认完整交付。" if text_only else "上一轮达到模型请求上限，未交付最终答复。"
  if previous_reason==STAGE:
   explanation="上一轮已交付预算内的阶段答复，整项任务的完成情况尚未确认。"
  print(explanation+"已核验同一 Thread 的现场。"
        "可以输入新的请求继续，或 /quit 退出。旧任务不会自动重试。",flush=True)
  return source
 stopped_source=None
 if (home/"needs-review.json").exists():
  stopped_source=review_stopped_turn()
 workspace=home/"workspace";workspace.mkdir(exist_ok=True)
 if a.cpu_fixture:
  (workspace/"index.md").write_text("# CPU protocol fixture\nThis is not a natural user Goal.\n")
 else:
  if a.guard is None:a.guard=auto_guard()
  owned_guard(a.guard)
  (home/"service-reference.json").write_text(json.dumps({"guard":str(a.guard),"run_id":json.loads((a.guard/"service/manifest.json").read_text())["run_id"],"scope":"references existing protected service; does not launch or reconfigure it"}))
 study.INPUT_ORIGIN = "cpu_fixture" if a.cpu_fixture else "controlled_rehearsal" if a.rehearsal else "operator_supplied"
 study.P["source_root"]=str(workspace)
 study.CPU=a.cpu_fixture;study.CPU_MODE="form_fixture" if a.cpu_form_fixture else None;study.CPU_RUN_NAME="pilot-cpu-"+a.profile
 study.PHASE="human-input";study.ARM="on"
 server=study.cpu_server() if a.cpu_fixture else None
 try:
  print("UAEA research pilot; profile="+str(home))
  print("Goal hypotheses are non-authoritative. /quit exits; the next launch resumes the same sealed Thread.")
  print("联网核查：输入 /web 加查询主题；也可单独输入 /web 接续上一条尚未执行的明确查询，或分行输入主题。授权只用于本次查询。", flush=True)
  print("连续研究可输入 /web on，本窗口可查公开网页；另行分析新对象时先搜，普通对话按需查询。/web off 关闭，退出窗口后自动关闭。",flush=True)
  session_web=None
  await_topic=object()
  def send(text,*,terminal_web=False):
   nonlocal session_web,stopped_source
   command=" ".join(text.strip().lower().split())
   explicit=command in ("/web on","/web off")
   if explicit or (session_web and revokes_session_web(text)):
    event_id=uuid.uuid4().hex
    enable=command=="/web on"
    study.append(home/"web-session-controls.jsonl",{"id":event_id,"command":"/web on" if enable else "/web off",
                  "source":"terminal_command" if explicit else "operator_revocation",
                  "input_sha256":study.digest(text.encode()),"previous_grant":session_web,"time":time.time()})
    session_web=event_id if enable else None
    print("本窗口已允许按需联网，换研究对象也有效。" if session_web else "会话联网已关闭，恢复按轮授权。",flush=True)
    if explicit:return
   latest=home/"latest.json"
   source=stopped_source or previous(home,inspect_checkpoint)
   if command_body(text)=="" and web_route(text,source).basis=="await_topic":
    print("请输入本次联网查询的主题。空行取消，/quit 退出。",flush=True)
    return await_topic
   out=home/"runs"/("turn-"+time.strftime("%Y%m%dT%H%M%S")+"-"+uuid.uuid4().hex[:8])
   blocked=home/"needs-review.json"
   blocked.write_text(json.dumps({"attempt":str(out),"reason":"turn in progress; cleared only after coherent seal"}))
   try:
    result=study.run_from(source,out,text,a.guard,terminal_web=terminal_web,session_web=session_web,mode="form_fixture" if a.cpu_form_fixture else None)
    resume=json.loads((out/"resume-manifest.json").read_text()) if (out/"resume-manifest.json").exists() else {}
   except (Exception,KeyboardInterrupt) as problem:
    # A sealed-copy failure can happen after a real final response was printed.
    if out.is_dir():
     try:prior_result=json.loads((out/"result.json").read_text())
     except (OSError,ValueError):prior_result={}
     record_outcome(out,blocked,prior_result,{},problem)
    raise
   try:
    source_note=calendar_notice(out,result)
   except (OSError, ValueError, KeyError, TypeError, IndexError) as exc:
    source_note={"scope":"current_turn","source_verification":"unavailable","error_type":type(exc).__name__,
                 "notice":"[UAEA Host · 来源核对] 本轮无法核对日期来源，相关结论尚未由本次来源校验确认。"}
   if source_note:
    study.dump(out/"source-calendar-check.json",source_note)
    print(source_note["notice"],flush=True)
   policy=json.loads((out/"web-access-policy.json").read_text())
   if result.get("delivery_validation",{}).get("terminal_confirmed"):
    activity=web_activity(policy["tool_names"],result.get("new_calls",[]),thread=result.get("thread"),turn=result.get("turn"))
    if activity:print(activity,flush=True)
    elif not a.cpu_fixture and not policy["enabled"]:
     print("[UAEA Host] 本轮未开放网页工具。连续联网可输入 /web on。",flush=True)
   if not record_outcome(out,blocked,result,resume)["advance_allowed"]:
    if result.get("reason") in ("REQUEST_BUDGET_NO_RETRY",TEXT_ONLY,STAGE) and resume.get("resume_eligible") is True:
     stopped_source=review_stopped_turn()
     return
    raise RuntimeError("Turn requires review; evidence retained at "+str(out))
   tmp=latest.with_suffix(".tmp");tmp.write_text(json.dumps({"checkpoint":str(out),"thread":result["thread"],"state_recoverable":True,"delivery_complete":True},ensure_ascii=False));tmp.replace(latest)
   blocked.unlink()
   stopped_source=None
   print("Saved research continuation: "+str(out),flush=True)
   return result
  if a.input_file:
   if a.cpu_fixture and not a.input_file.resolve().is_relative_to(B):raise RuntimeError("CPU fixture input must be inside isolated root")
   try:
    text = a.input_file.read_text(encoding="utf-8").removesuffix("\n")
    validate_input_text(text)
   except UnicodeError:
    p.exit(2,"输入文件必须是有效的 UTF-8。本条未提交。\n")
   send(text)
  else:
   with utf8_terminal_erase(sys.stdin):
    read_line = line_reader()
    pending_web=False
    while True:
     try:
      text = read_line("\n联网查询> " if pending_web else "\n你 [联网可用]> " if session_web else "\n你> ")
      validate_input_text(text)
     except EOFError:
      break
     except UnicodeError:
      print("这条输入中有无法识别的字符，尚未提交。请重新输入或粘贴整条消息。", flush=True)
      continue
     if text.strip() in ("/quit","/exit"):break
     if not text.strip():
      pending_web=False
      continue
     pending_web=send(text,terminal_web=pending_web) is await_topic
 finally:
  if server:server.shutdown();server.server_close()
  fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
if __name__=="__main__":main()
