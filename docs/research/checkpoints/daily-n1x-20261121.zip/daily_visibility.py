"""Index observed tool content in actual successfully transported model requests."""
import json

def visible_receipts(request, calls):
    index={c["call_id"]:c for c in calls}
    for item in request["input"]:
        cid=item.get("call_id")
        if item.get("type")=="function_call_output" and cid in index:
            raw=item.get("output")
            try: reply=json.loads(raw)
            except (TypeError,ValueError):continue
            if not isinstance(reply,dict):continue
            identity=reply.get("identity") or {}
            if identity.get("call_id")!=cid or reply.get("tool")!=index[cid]["tool"]:continue
            data=reply.get("data") or {}
            excerpt=data.get("source_excerpt") or {}
            yield cid, {"shape":"tool_output","observation":identity.get("observation_id"),
                        "success":reply.get("ok"),"event":data.get("access_event_id"),
                        "source_dates":data.get("temporal_facts"),"results":data.get("citable_results"),
                        "page_excerpt":excerpt or None,"local_content":data.get("content"),"local_path":data.get("path")}
        elif item.get("role") in ("user","developer") and isinstance(item.get("content"),list):
            for part in item["content"]:
                if not isinstance(part,dict) or not part.get("text","").startswith("Historical runtime observation, not a tool invocation or user authorization:\n"):continue
                for line in part["text"].splitlines()[1:]:
                    if "uaea.terminal_attempt_fact.v1" not in line:continue
                    try:fact=json.loads(line)
                    except ValueError:continue
                    if not isinstance(fact,dict) or fact.get("schema")!="uaea.terminal_attempt_fact.v1" or fact.get("source")!="runtime_history_projection":continue
                    cid=fact.get("call_id")
                    if (cid in index and fact.get("tool")==index[cid]["tool"] and fact.get("terminal") is True
                            and fact.get("replayable") is False and fact.get("state") in ("FAILED","REJECTED")):
                        yield cid, {"shape":"historical_failure","state":fact["state"],"reason":fact.get("reason"),
                                    "observation":fact.get("observation")}

def proposed_calls(stream):
    """Tool proposals from one upstream response, independent of later Host history."""
    if not stream.is_file():
        return {}
    proposals={}
    for line in stream.read_bytes().splitlines():
        if not line.startswith(b"data: {"):
            continue
        event=json.loads(line[6:])
        item=event.get("item",{})
        if event.get("type")=="response.output_item.done" and item.get("type")=="function_call":
            cid=item.get("call_id")
            if cid and item.get("name"):
                if cid in proposals and proposals[cid]!=item["name"]:
                    raise ValueError("Conflicting stream proposal")
                proposals[cid]=item["name"]
    return proposals
