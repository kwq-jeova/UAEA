from pathlib import Path
from copy import deepcopy
import json,sys
B=Path(__file__).resolve().parent
sys.path.insert(0,str(B));import pilot
ok={"terminal":"completed","classification":"completed","delivery_validation":{"delivery_complete":True,"terminal_confirmed":True}}
recover={"resume_eligible":True,"stop_reason":"completed"}
cases=[("complete_delivery",ok,recover,True)]
for label in ("budget_stop","execution_failure","external_interrupt","resource_stop"):
 value={"terminal":"interrupted","classification":label,"reason":"CPU injected "+label,"answers":[]}
 cases.append((label+"_native_terminal_cache_complete",value,recover,False))
value=deepcopy(ok);value["classification"]="task_incomplete";value["delivery_validation"].update({"delivery_complete":False,"upstream_status":"incomplete","upstream_incomplete_reason":"max_output_tokens"})
cases.append(("real_upstream_incomplete_is_not_delivery",value,recover,False))
value=deepcopy(ok);value.pop("delivery_validation");cases.append(("missing_delivery_proof",value,recover,False))
value=deepcopy(ok);value["delivery_validation"]["terminal_confirmed"]=False;cases.append(("unconfirmed_native_terminal",value,recover,False))
cases.append(("complete_answer_unrecoverable_state",ok,{"resume_eligible":False},False))
cases.append(("unknown_result_recoverable_native",{},recover,False))
rows=[]
for name,result,resume,expected in cases:
 got=pilot.classify_turn_outcome(result,resume)
 assert got["advance_allowed"] is expected,(name,got)
 assert got["state_recoverable"] is (resume.get("resume_eligible") is True)
 rows.append({"name":name,"expected_advance":expected,"outcome":got,"pass":True})
actual=sorted((B/"cpu-profiles/goalform170/runs").glob("*"))[-1]
got=pilot.classify_turn_outcome(json.loads((actual/"result.json").read_text()),json.loads((actual/"resume-manifest.json").read_text()))
assert got["delivery_complete"] and got["advance_allowed"]
rows.append({"name":"existing_real_Native_CPU_delivery_accepts","outcome":got,"pass":True})
text=(B/"pilot.py").read_text()
assert text.index('fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)')<text.index('if (home/"needs-review.json").exists()')
rows.append({"name":"review_latch_checked_after_exclusive_lock","pass":True})
(B/"entry-outcome-cpu.json").write_text(json.dumps({"scope":"CPU outcome policy counterexamples; no model/service requests","checks":rows},ensure_ascii=False,indent=2))
print("PASS",len(rows))
