import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import study
from daily_web import (DailyWebAdapter, WEB_NAMES, check_wire, explicit_provider,
                       permitted_tools, public_address, stage_resume_catalogue)
from urllib.error import URLError


class DailyWebTests(unittest.TestCase):
    def test_current_task(self):
        self.assertEqual(permitted_tools("研究这个指数，需要材料你可以从google站点搜索，给个摘要。"), WEB_NAMES)
        self.assertEqual(permitted_tools("/web 核验官方说明"), WEB_NAMES)
        self.assertEqual(permitted_tools("请联网搜索来源"), WEB_NAMES)
        self.assertEqual(explicit_provider("你可以从google站点搜索"), "google")

    def test_spaced_grant_and_revocation(self):
        for text in ("需要材料你可以从 Google 站点搜索，取消限制",
                     "看看资料，需要材料你可以从 GOOGLE 站点 搜索。"):
            self.assertEqual(permitted_tools(text), WEB_NAMES)
        self.assertEqual(permitted_tools("“需要材料你可以从 Google 站点搜索”，是什么意思？"),set())
        self.assertEqual(permitted_tools("需要材料你可以从 Google 站点搜索，但这次不要联网"),set())

    def test_turn_notice_preserves_history_and_only_names_exposed_tools(self):
        from daily_web import current_web_notice
        old={"role":"assistant","content":"以前无法联网"}
        req={"input":[old],"tools":[]}
        current_web_notice(req,[])
        self.assertEqual(req["input"][:-1],[old])
        self.assertIn("本轮处于离线模式",req["input"][-1]["content"][0]["text"])
        req["input"]=[old]
        schema={"type":"object","properties":{"provider":{"enum":["google","bing"]},"allow_fallback":{"type":"boolean"}},"required":["query"]}
        spec={"name":"web_search","inputSchema":schema,"description":"find sources"}
        req["tools"]=[{"name":"web_search","parameters":schema,"description":"find sources"}]
        current_web_notice(req,[spec])
        self.assertEqual(req["input"][:-1],[old])
        notice=req["input"][-1]["content"][0]["text"]
        self.assertIn("web_search",notice)
        self.assertNotIn("web_fetch",notice)

    def test_report_counts_only_current_native_calls(self):
        from daily_web import web_activity
        self.assertEqual(web_activity(["read_section"],[]),"")
        names=["read_section","web_search","web_fetch"]
        self.assertIn("web_search 0 次",web_activity(names,[]))
        # A failed invocation still counts as a call, not successful acquisition.
        self.assertIn("web_search 1 次",web_activity(names,[{"tool":"web_search","success":False}]))

    def test_explicit_search_vs_optional_permission(self):
        from daily_web import requested_first_tool
        self.assertEqual(requested_first_tool("/web 请用 Google 搜索 最近一个月收盘价格",WEB_NAMES),"web_search")
        for text in ("需要材料你可以从 Google 站点搜索，取消限制", "/web 可以查资料", "/web 请用 Google 搜索"):
            self.assertIsNone(requested_first_tool(text,WEB_NAMES))
        self.assertIsNone(requested_first_tool("/web 请用 Google 搜索 指数",{"web_fetch"}))

    def test_current_search_protocol_reflects_provider_boundary(self):
        from daily_web import bind_search_scope
        schema={"properties":{"provider":{"enum":["google","bing"]},"allow_fallback":{"type":"boolean"}},"required":["query"]}
        q={"tools":[{"name":"web_search","parameters":schema}]}
        bind_search_scope(q,None)
        self.assertIs(q["tools"][0]["strict"],True)
        self.assertEqual(schema["required"],["query"])
        self.assertEqual(schema["properties"]["provider"]["enum"],["google","bing"])
        self.assertEqual(schema["properties"]["allow_fallback"]["enum"],[False])
        bind_search_scope(q,"google")
        self.assertEqual(schema["properties"]["provider"]["enum"],["google"])
        self.assertEqual(schema["required"],["query","provider","allow_fallback"])

    def test_current_host_policy_and_current_command_intersect(self):
        from daily_web import bind_search_scope
        for kind,constraints,local,expected in [
            ("application",["web.provider=google"],None,["google"]),
            ("untrusted",["web.provider=google"],None,["google","bing"]),
            ("application",["web.exclude_provider=google"],None,["bing"]),
            ("application",["web.provider=google"],"bing",[]),
            ("application",["web.provider=google","web.exclude_provider=google"],None,[]),
            ("application",["web.fallback=allowed"],None,["google","bing"]),
        ]:
            with self.subTest(kind=kind,constraints=constraints,local=local):
                schema={"properties":{"provider":{"enum":["google","bing"]},"allow_fallback":{"type":"boolean"}},"required":["query"]}
                other={"name":"web_fetch"}
                req={"tools":[{"name":"web_search","parameters":schema},other]}
                block={"kind":kind,"value":json.dumps({"constraints":constraints})}
                bind_search_scope(req,local,block)
                self.assertIn(other,req["tools"])
                if expected:
                    self.assertEqual(schema["properties"]["provider"]["enum"],expected)
                    self.assertEqual(schema["properties"]["allow_fallback"]["enum"],[False])
                else:
                    self.assertEqual(req["tools"],[other])
        q={"tools":[{"name":"read_section"}]}
        bind_search_scope(q,None,{"kind":"application","value":json.dumps({"constraints":["web.provider=google"]})})
        self.assertEqual(q["tools"],[{"name":"read_section"}])

    def test_web_status_reports_scope_of_real_rejection(self):
        from daily_web import web_activity
        outcome={"identity":{"call_id":"abc"},"data":{"failure_scope":"web.provider_fallback"}}
        call={"id":"abc","tool":"web_search","success":False,"contentItems":[{"text":json.dumps(outcome)}]}
        self.assertIn("Host 拒绝的是切换搜索服务商",web_activity(["web_search"],[call]))
        call["id"]="other"
        self.assertNotIn("Host 拒绝的是切换搜索服务商",web_activity(["web_search"],[call]))

    def test_release_only_continues_immediately_unattempted_search(self):
        from daily_web import web_route
        release="需要材料你可以从 Google 站点搜索，取消限制"
        text="/web google搜索纳斯达克100指数10月份以来的走势，以及最近5日低于250日均线的情况，转换为英文搜索，与我对话保持中文"
        with tempfile.TemporaryDirectory() as tmp:
            prev=Path(tmp)
            study.dump(prev/"input.json",{"text":text})
            result={"new_calls":[],"thread":"t","turn":"u","delivery_validation":{"delivery_complete":True}}
            study.dump(prev/"result.json",result)
            event={"method":"item/completed","params":{"threadId":"t","turnId":"u","item":{
                    "type":"userMessage","id":"m","content":[{"type":"text","text":text}]}}}
            native=prev/"app-server-events.jsonl"
            native.write_text(json.dumps({"message":event}))
            for msg in (release,"/web"):
                route=web_route(msg,prev)
                self.assertEqual((route.first_tool,route.provider,route.previous_text),("web_search","google",text))
            for msg in ("你可以从 Google 站点搜索", release+"，这次只解释","继续","取消限制"):
                self.assertIsNone(web_route(msg,prev).first_tool)
            result["new_calls"]=[{"tool":"web_search","success":False}]
            study.dump(prev/"result.json",result)
            self.assertEqual(web_route("/web",prev).basis,"await_topic")
            self.assertIsNone(web_route(release,prev).first_tool)
            result["new_calls"]=[];study.dump(prev/"result.json",result)
            event["params"]["turnId"]="other";native.write_text(json.dumps({"message":event}))
            self.assertEqual(web_route("/web",prev).basis,"await_topic")
            event["params"]["turnId"]="u";event["params"]["item"]["content"][0]["text"]="different"
            native.write_text(json.dumps({"message":event}))
            self.assertEqual(web_route("/web",prev).basis,"await_topic")

    def test_web_command_topic_does_not_require_particular_phrasing(self):
        from daily_web import web_route
        for text in ("/web google搜索指数","/WEB Google 搜索 指数","/web 谷歌搜 指数"):
            plan=web_route(text)
            self.assertEqual((plan.first_tool,plan.provider),("web_search","google"))
        for text in ("/web 核验官方说明", '/web "exact phrase"'):
            self.assertEqual(web_route(text).first_tool,"web_search")
        self.assertEqual(web_route("/web https://example.com").first_tool,"web_fetch")
        self.assertEqual(web_route("/web").basis,"await_topic")

    def test_pending_one_turn_keeps_user_text_scope(self):
        from daily_web import web_route
        self.assertEqual(web_route("google搜索指数",terminal_web=True),web_route("/web google搜索指数"))
        self.assertEqual(web_route("仅搜索，不要访问网页",terminal_web=True).names,{"web_search"})
        self.assertFalse(web_route("只用本地",terminal_web=True).names)
        self.assertFalse(web_route("google搜索指数").names)

    def test_offline(self):
        for text in ("接着做", "你能上网吗？", "用户昨天说“请联网搜索资料”，这句话的意思是什么？",
                     "请解释“，需要材料你可以从google站点搜索，”", "/websocket 开始",
                     "/web 请不要联网，只看本地", "/web"):
            with self.subTest(text=text):
                self.assertEqual(permitted_tools(text), set())

    def test_narrow_grant(self):
        self.assertEqual(permitted_tools("/web 仅搜索，不要访问网页"), {"web_search"})
        self.assertEqual(permitted_tools("/web 请打开指定网页，请勿搜索"), {"web_fetch"})

    def test_optional_grant_and_subject_change(self):
        from daily_web import web_route
        conditional="这里从vix隐含波动率来看，能否解释这种现象？或者从你的视角分析，你会如何分析？如果需要资料你可以继续联网搜索"
        self.assertEqual(web_route(conditional).names, WEB_NAMES)
        self.assertIsNone(web_route(conditional).first_tool)
        for msg in ("你可以联网搜索吗？","解释“如果需要资料你可以继续联网搜索”", conditional+"，但这轮不要联网"):
            self.assertFalse(web_route(msg).names)
        soxx="从估值、基本面、eps角度呢，你可以单独分析soxx板块"
        self.assertFalse(web_route(soxx).names)
        self.assertEqual(web_route(soxx,session_web="grant").names,WEB_NAMES)
        self.assertEqual(web_route(soxx,session_web="grant").first_tool,"web_search")
        self.assertEqual(web_route("另外调查新版教材",session_web="grant").basis,"session_new_research")
        self.assertIsNone(web_route("解释“单独分析这个指数”",session_web="grant").first_tool)
        self.assertFalse(web_route(soxx+"，只用现有数据",session_web="grant").names)
        self.assertIsNone(web_route(soxx+"，如果需要资料你可以继续联网搜索",session_web="grant").first_tool)
        self.assertFalse(web_route("这轮不要联网",session_web="grant").names)
        self.assertFalse(web_route("仅用本地",session_web="grant").names)
        self.assertEqual(web_route("请你继续联网搜索 SOXX 数据").first_tool,"web_search")

    def test_persistent_off_vs_local_veto(self):
        from daily_web import revokes_session_web, web_route
        self.assertTrue(revokes_session_web("今后不要联网。请写这份摘要"))
        self.assertFalse(revokes_session_web("本轮不要联网"))
        self.assertFalse(revokes_session_web("解释“今后不要联网”"))
        self.assertFalse(web_route("/web 本轮不要联网",session_web="grant").names)

    def test_resume_search_depends_on_observed_web_work_and_current_directive(self):
        from daily_web import web_route
        req="请你继续尝试搜索获得数据，以完成当前分析的工作"
        self.assertFalse(web_route(req).names)
        with tempfile.TemporaryDirectory() as tmp:
            prev=Path(tmp)
            text = "换一个分析对象"
            study.dump(prev/"input.json", {"text": text})
            study.dump(prev/"web-access-policy.json", {
                "enabled": True, "tool_names": ["web_search"],
                "input_sha256": hashlib.sha256(text.encode()).hexdigest()})
            action = {"harness": {"turn_id": "u", "input_id": "input"},
                      "execution_contract": {"allowed": True, "effective_parameters": {
                          "provider": "google", "allow_fallback": False}},
                      "host_execution_receipt": {"execution_observation": {"observation_id": "obs-1"},
                          "result": {"tool": "web_search", "data": {"http_attempted": True}}}}
            attempt = {"capability": "web.search", "workflow_id": "t", "execution_observation_id": "obs-1",
                       "action": action}
            flow = {"workflow_id": "t", "attempts": [attempt]}
            env = {"snapshot": {"task_id": "t", "last_turn_id": "u", "current_input_id": "input",
                                "workflow_continuity": flow}}
            for cap, work, obs, expected in (("web.search","t","obs-1",True),("document.read_section","t","obs-1",False),
                                             ("web.search","other","obs-1",False),("web.search","t","",False)):
                attempt.update(capability=cap,workflow_id=work,execution_observation_id=obs)
                study.dump(prev/"after-state.json",env)
                self.assertEqual(web_route(req,prev).first_tool,"web_search" if expected else None)
                self.assertFalse(web_route("换一个对象",prev).names)
            attempt.update(capability="web.search",workflow_id="t",execution_observation_id="obs-1")
            flow["attempts"].append({"workflow_id":"t","capability":"document.read_section","action":action})
            study.dump(prev/"after-state.json",env)
            self.assertFalse(web_route(req,prev).names)
            flow["attempts"].pop()
            study.dump(prev/"after-state.json",env)
            local = "这轮只用本地资料"
            study.dump(prev/"input.json",{"text":local})
            study.dump(prev/"web-access-policy.json", {"enabled":True, "tool_names":["web_search"],
                "input_sha256":hashlib.sha256(local.encode()).hexdigest()})
            self.assertFalse(web_route(req,prev).names)
            self.assertFalse(web_route(req+"，只查本地",prev).names)

    def test_pinned_public_destinations(self):
        with patch("socket.getaddrinfo",return_value=[(2,1,0,"",("127.0.0.1",443))]):
            with self.assertRaises(URLError):
                public_address("example.test")

    def test_provider_constraint_precedes_egress(self):
        from harness.observation_boundary import CapabilityInputError
        with self.assertRaises(CapabilityInputError):
            DailyWebAdapter(snapshot_root=Path("."),provider="google").search(None, "fixture")

    def test_absent_tool_cannot_escape(self):
        with self.assertRaises(ValueError):
            check_wire({"tools":[{"name":"web_fetch"}]}, [])
        with self.assertRaises(ValueError):
            check_wire({"tools":[]}, [{"name":"web_search"}])

    def test_resume_changes_only_catalogue_in_copy(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); out=root/"run"; workdir=out/"codex-home/sessions"
            workdir.mkdir(parents=True); source=root/"original"; work=workdir/"rollout.jsonl"
            saved=[{"name":"goal_hypothesis"}]; enabled=saved+[{"name":"web_search"}]
            tail=b'{"type":"event_msg","payload":{"test":1}}\n'
            row={"type":"session_meta","payload":{"id":"thread","dynamic_tools":saved}}
            raw=json.dumps(row).encode()+b"\n"+tail;source.write_bytes(raw);work.write_bytes(raw)
            proof={"rollout_original":str(source),"rollout_copy":str(work),"thread_id":"thread",
                   "rollout_sha256":hashlib.sha256(raw).hexdigest(),"dynamic_tools_SQLite_rows":0}
            study.dump(out/"native-copy-proof.json",proof)
            stage_resume_catalogue(out,"thread",enabled,study.dump)
            header,events=work.read_bytes().split(b"\n",1)
            self.assertEqual(json.loads(header)["payload"]["dynamic_tools"],enabled)
            self.assertEqual(events,tail)
            self.assertEqual(source.read_bytes(),raw)
            self.assertEqual(json.loads((out/"web-resume-catalogue.json").read_text())
                             ["unchanged_event_tail_sha256"],hashlib.sha256(tail).hexdigest())


if __name__ == "__main__":
    unittest.main()
