from copy import deepcopy
import unittest

from daily_delivery_check import CLOSING_NOTE, reserve_answer, closing_envelope

class BudgetAnswerTests(unittest.TestCase):
    def setUp(self):
        self.req={"tools":[{"name":"read_section"}], "tool_choice":"auto",
                  "input":[{"type":"function_call_output","call_id":"x","output":"真实回执"}]}

    def test_nonfinal_projection_unchanged(self):
        for compact in (True,False):
            before=deepcopy(self.req)
            self.assertIsNone(reserve_answer(self.req,compact=compact,last=False))
            self.assertEqual(self.req,before)

    def test_native_compact_at_cap_stays_in_control(self):
        before=deepcopy(self.req)
        self.assertEqual(reserve_answer(self.req,compact=True,last=True),"last_slot_native_compaction")
        self.assertEqual(self.req,before)

    def test_ordinary_last_slot_preserves_catalogue_and_receipts(self):
        before=deepcopy(self.req)
        self.assertEqual(reserve_answer(self.req,compact=False,last=True),"budget_answer_reserved")
        self.assertEqual(self.req["tool_choice"],"none")
        self.assertEqual(self.req["tools"],before["tools"])
        self.assertEqual(self.req["input"][:-1],before["input"])
        self.assertEqual(self.req["input"][-1]["content"][0]["text"],CLOSING_NOTE)

    def test_nonweb_literal_tool_is_also_unfinished(self):
        raw="<tool_call><function=read_section></function></tool_call>"
        self.assertEqual(closing_envelope(raw)[1],"read_section")
        self.assertIsNone(closing_envelope("```\n"+raw+"\n```"))
