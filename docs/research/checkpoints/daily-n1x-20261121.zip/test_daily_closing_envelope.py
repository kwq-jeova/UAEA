import json
import unittest
from daily_delivery_check import closing_envelope
CALL='<tool_call>\n<function=web_fetch>\n<parameter=url>\nhttps://example.org/missing\n</parameter>\n</function>\n</tool_call>'
class ClosingEnvelopeTests(unittest.TestCase):
    def test_closing_call_with_preamble(self):
        for text in (CALL, '\n'+CALL+'\n', '已取页三次，未取得通知。\n我将再试。\n'+CALL+'\n'):
            self.assertEqual(closing_envelope(text)[1],'web_fetch')
    def test_quoted_fenced_inline_and_followed_by_explanation(self):
        for text in ('原样示例：'+CALL, '> '+CALL, '示例：\n\n    '+CALL, '示例：\n\t'+CALL, '```xml\n'+CALL+'\n```', '~~~xml\n'+CALL, CALL+'\n该调用只是示例。'):
            self.assertIsNone(closing_envelope(text))
    def test_finished_code_example_before_actual_call(self):
        self.assertEqual(closing_envelope('```xml\n<old/>\n```\n'+CALL)[1],'web_fetch')
