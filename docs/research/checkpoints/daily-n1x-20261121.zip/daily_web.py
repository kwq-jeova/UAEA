"""Current-input opt-in for public web reads in the daily entry."""
from __future__ import annotations

import hashlib
import http.client
import ipaddress
import json
import os
from pathlib import Path
import re
import socket
import tempfile
from copy import deepcopy
from dataclasses import dataclass, replace
from urllib.error import URLError
from urllib.parse import urlsplit
from urllib.request import HTTPSHandler, HTTPRedirectHandler, build_opener

from harness.execution_host import SharedExecutionHost
from runtime.tools import ToolRegistry
from phase2.web_adapter import SUPPORTED_SEARCH_PROVIDERS, WebAdapter

WEB_NAMES = {"web_search", "web_fetch"}
NATURAL = re.compile(r"^(?:本轮允许联网[，。,:：\s]|请联网(?:搜索|核查|查证|查阅)|请(?:用|通过)\s*(?:Google|谷歌)\s*(?:搜索|查询)|需要材料[，,]?\s*你可以从\s*(?:Google|谷歌)\s*站点\s*搜索)", re.I)


# Only accept a command, a direct instruction at the start, or a complete
# explicit grant clause. Never derive network permission from stored dialogue.
GRANT_CLAUSE = re.compile(
    r"(?:^|[，,。；;\n])\s*(?:需要材料[，,]?\s*)?你可以从\s*(?:Google|谷歌)\s*站点\s*搜索"
    r"(?=\s*(?:[，,。；;\n]|$))", re.I)
NEGATIVE = r"(?:不要|请勿|禁止|不许|无需|不需要|不可|不能|不允许|不必|不准|不再|不用|不得|别|勿|不)\s*(?:(?:再|继续)\s*)?"
ONLY = r"(?:只|仅)(?:允许|能|可|需|限于|限)?\s*"
DENY_WEB = re.compile(
    rf"{NEGATIVE}(?:使用网络|联网|上网|网上(?:搜索|查询|查阅))|{ONLY}(?:搜索|查阅|检索|使用|用|查|看)?本地"
    r"|(?:保持离线|离线(?:答复|回答|处理))")
SEARCH_ACTION = r"(?:搜索|检索|查询)"
FETCH_ACTION = r"(?:打开|访问|抓取|读取|取页)"
DENY_FETCH = re.compile(rf"{ONLY}{SEARCH_ACTION}|{NEGATIVE}{FETCH_ACTION}(?:网页|页面|链接|网站|网址)")
DENY_SEARCH = re.compile(rf"{ONLY}{FETCH_ACTION}|{NEGATIVE}{SEARCH_ACTION}")
QUOTED = re.compile(r'“[^”]*(?:”|$)|「[^」]*(?:」|$)|『[^』]*(?:』|$)|‘[^’]*(?:’|$)|"[^"]*(?:"|$)|`[^`]*(?:`|$)|(?<![A-Za-z0-9])\x27[^\x27]*\x27')


OPTIONAL_SEARCH = re.compile(
    r"(?:^|[，,。！？!?；;\n])\s*(?:(?:如果|若|如)?(?:需要|需)(?:数据|资料|材料|时)?[，,\s]*)?"
    r"(?:你|您)?(?:可以|可按需|可)(?:继续)?(?:联网|上网)(?:搜索|查找|查询|查阅|核实|查证)"
    r"(?=\s*(?:[，,。！!；;\n]|$))")
DIRECT_WEB = re.compile(
    r"^(?:请(?:你|您)?|麻烦(?:你|您)?)(?:再|继续)?(?:尝试|试着)?(?:联网|上网)"
    r"(?:搜索|搜一下|检索|查找|查询|核查|查证|查阅)")
# In operator-selected web research mode, an explicit assignment to research
# another subject starts a fresh lookup. Discussion and conditional grants stay auto.
NEW_RESEARCH = re.compile(
    r"(?:^|[，,。！？!?；;\n])\s*(?:(?:请(?:你|您)?|你(?:可以)?|您(?:可以)?|帮我|接下来|现在)\s*)*"
    r"(?:(?:单独|另外|另行|改为|转而|换成|(?:用|按|沿用)(?:同样|相同)的?方法)(?:研究|分析|调查|考察)"
    r"|(?:换(?:一个|个)?(?:对象|标的|主题)[，,：:\s]*(?:研究|分析|调查)))\s*[^，,。！？!?\s]")
EXISTING_ONLY = re.compile(r"(?:只|仅)(?:用|按|根据|基于|用到)(?:当前|现有|已有|上述|以上|刚才|上轮)(?:的)?(?:数据|资料|材料|结果)|(?:不用|不必)(?:再)?查(?:新资料|网络|网页|网上)|不查新资料")
# A request to resume an unspecified search is ambiguous in a fresh or local
# task. Only resolve this wording against a recorded public-search operation.
RESUME_SEARCH = re.compile(
    r"^(?:请(?:你|您)?|麻烦(?:你|您)?)?(?:继续|再次|再)(?:尝试|试着)?(?:搜索|检索)"
    r"(?:以|来)?(?:获取|获得|收集)(?:所需|相关)?(?:资料|数据)"
    r"(?:[，,]?\s*(?:以|来)?完成(?:当前|本次|这次|上述)(?:分析|研究|查询)(?:的工作|任务)?)?[。！!\s]*$")



FETCH_DIRECTIVE = re.compile(rf"{ONLY}(?:打开|访问|读取|抓取)")
TARGET_WORDS = r"(?:(?:这(?:一?个|些|几个)|该|此|指定的?|目标|以下|下列|下面的?)\s*(?:网址|链接|网页|页面|URL))"
URI_TOKEN = re.compile(r"""[a-z][a-z0-9+.-]*://[^\s<>"'《》“”‘’【】（）\x60，。；！？、]+""", re.I)
TARGET_PREFIX = re.compile(rf"^\s*(?:{TARGET_WORDS})?\s*[：:\s<《“‘\x22\x27\x60]*$", re.I)


def explicit_fetch_targets(text):
    """None gives the ordinary fetch tool. An empty tuple grants no destination."""
    # Preserve offsets so a literal URL can be written in quotes or backticks.
    unquoted = QUOTED.sub(lambda match: " " * len(match[0]), text)
    for marker in FETCH_DIRECTIVE.finditer(unquoted):
        tail = text[marker.end():]
        urls = list(URI_TOKEN.finditer(tail))
        if not urls:
            first_clause = re.split(r"[，,。；;！？!?\n]", tail, maxsplit=1)[0].strip()
            if re.fullmatch(r"(?:网页|页面|网址|链接|网站)?", first_clause):
                continue
            return ()
        if len(urls) != 1 or not TARGET_PREFIX.fullmatch(tail[:urls[0].start()]):
            return ()
        url = urls[0][0]
        try:
            parts = urlsplit(url)
            if (parts.scheme != "https" or not parts.hostname or parts.username is not None
                    or parts.password is not None or parts.port not in (443, None)):
                return ()
        except ValueError:
            return ()
        return (url,)
    return None


def revokes_session_web(text):
    plain = QUOTED.sub(" ", text).strip()
    return bool(re.search(r"(?:^|[，,。；;！？!?\n])\s*(?:从现在(?:开始|起)|以后|今后|后续|接下来)"
                          r"[，,\s]*(?:请)?(?:都)?(?:不再|不要|禁止|别)(?:再)?(?:联网|上网|使用网络)",plain))


def permitted_tools(text, *, session_web=False, resumed_search=False):
    request = QUOTED.sub(" ", text.strip())
    if DENY_WEB.search(request) or EXISTING_ONLY.search(request) or revokes_session_web(text):
        return set()
    if not (session_web or resumed_search or bool(command_body(text)) or NATURAL.match(request)
            or DIRECT_WEB.match(request) or GRANT_CLAUSE.search(request) or OPTIONAL_SEARCH.search(request)):
        return set()
    names = set(WEB_NAMES)
    if DENY_FETCH.search(request):
        names.discard("web_fetch")
    if DENY_SEARCH.search(request):
        names.discard("web_search")
    return names


PROVIDER = r"Google|谷歌|Bing|DuckDuckGo"
SEARCH_VERB = r"搜索|查询|检索|查找|搜一下|搜一搜|搜|search"
SEARCH_COMMAND = re.compile(
    rf"^(?:请)?(?:(?:(?:用|通过|使用)\s*)?(?P<provider>{PROVIDER})\s*|联网\s*)?"
    rf"(?:{SEARCH_VERB})[：:，,\s]*(?P<subject>.*)$", re.I)
OPTIONAL = re.compile(r"^(?:如需|如果|可以|允许|需要(?:材料|时)|按需|不必|无需|先别|先不要|不要|仅授权|只授权|请解释)|(?:能|可以)联网吗")
RELEASE = re.compile(r"^(?P<grant>.+)[，,。；;]\s*取消限制[。！!]?$",re.I)


def command_body(text):
    words = text.strip().split(maxsplit=1)
    if words and words[0].casefold() == "/web":
        return words[1].strip() if len(words) > 1 else ""
    return None


def requested_first_tool(text, names):
    body = command_body(text)
    content = text.strip() if body is None else body
    plain = QUOTED.sub(" ",content).strip()
    if not names or not content or OPTIONAL.search(plain):
        return None
    match = SEARCH_COMMAND.match(content)
    if match:
        if "web_search" in names and match["subject"].strip(" 。，：:！!？?"):
            return "web_search"
        return None
    if body is None:
        return None
    # A URL supplied as a destination is a page read. An ordinary /web topic
    # requests discovery even when the operator has not used a search verb.
    if re.search(r"https?://",content,re.I):
        return "web_fetch" if "web_fetch" in names else None
    return "web_search" if "web_search" in names else None


PROVIDER_GROUP = rf"(?:{PROVIDER})(?:\s*(?:、|,|，|/|或(?:者)?|与|和|及)\s*(?:{PROVIDER}))*"
PROVIDER_VERB = r"(?:使用|通过|用|从|切换到|改用|选用)"
PROVIDER_CLAUSE = re.compile(
    rf"(?:(?P<deny>{NEGATIVE})(?:{PROVIDER_VERB})?|{PROVIDER_VERB})\s*(?P<choices>{PROVIDER_GROUP})",
    re.I)


def provider_scope(text):
    plain = QUOTED.sub(" ", text).strip()
    body = command_body(plain)
    command = SEARCH_COMMAND.match(plain if body is None else body)
    positive, excluded = set(), set()

    def canonical(name):
        return "google" if name == "谷歌" else name.casefold()

    if command and command["provider"]:
        positive.add(canonical(command["provider"]))
    for match in PROVIDER_CLAUSE.finditer(plain):
        target = excluded if match["deny"] else positive
        target.update(canonical(p) for p in re.findall(PROVIDER, match["choices"], re.I))
    if len(positive) > 1:
        excluded.update(SUPPORTED_SEARCH_PROVIDERS - positive)
    return next(iter(positive)) if len(positive) == 1 else None, frozenset(excluded)


def explicit_provider(text):
    return provider_scope(text)[0]


def unattempted_search(previous_run):
    if previous_run is None:
        return None
    result = json.loads((previous_run/"result.json").read_text())
    calls = result.get("new_calls")
    if (result.get("delivery_validation",{}).get("delivery_complete") is not True
            or not isinstance(calls,list) or any(c.get("tool") in WEB_NAMES for c in calls)):
        return None
    text = json.loads((previous_run/"input.json").read_text())["text"]
    if requested_first_tool(text,permitted_tools(text)) != "web_search":
        return None
    # A continuation can initiate real egress. Bind its task to the actual
    # Native user message for the selected sealed Turn, not just input.json.
    user_items = {}
    with (previous_run/"app-server-events.jsonl").open() as stream:
        for line in stream:
            event=json.loads(line).get("message",{})
            params=event.get("params") or {}
            item=params.get("item") or {}
            if (event.get("method")=="item/completed" and params.get("threadId")==result["thread"]
                    and params.get("turnId")==result["turn"] and item.get("type")=="userMessage"):
                content=item.get("content",[])
                if len(content)!=1 or content[0].get("type")!="text" or content[0].get("text")!=text:
                    return None
                user_items[item["id"]]=text
    return text if len(user_items)==1 else None


@dataclass(frozen=True)
class WebRoute:
    names: frozenset
    provider: str | None = None
    first_tool: str | None = None
    basis: str = "auto"
    previous_text: str | None = None
    excluded_providers: frozenset = frozenset()
    fetch_targets: tuple[str, ...] | None = None


def prior_public_search(previous_run):
    """Resolve a current request to continue searching against the immediately preceding input."""
    if previous_run is None or not (previous_run / "web-access-policy.json").is_file():
        return None
    policy = json.loads((previous_run / "web-access-policy.json").read_text())
    if policy.get("enabled") is not True or "web_search" not in policy.get("tool_names", ()):
        return None
    last_input = json.loads((previous_run / "input.json").read_text())["text"]
    if (policy.get("input_sha256") != hashlib.sha256(last_input.encode()).hexdigest()
            or "web_search" not in permitted_tools(last_input, session_web=True)):
        return None

    snapshot = json.loads((previous_run / "after-state.json").read_text())["snapshot"]
    workflow = snapshot["workflow_continuity"]
    task, turn, input_id = (snapshot.get(k) for k in ("task_id", "last_turn_id", "current_input_id"))
    if not all((task, turn, input_id)) or workflow.get("workflow_id") != task:
        return None
    # Attempts accumulate across turns. Neither a prior grant nor that list's
    # last entry, by itself, identifies a search made for the preceding input.
    attempts = []
    for step in workflow["attempts"]:
        harness = step.get("action", {}).get("harness", {})
        if (step.get("workflow_id") == task and harness.get("turn_id") == turn
                and harness.get("input_id") == input_id):
            attempts.append(step)
    if not attempts or attempts[-1].get("capability") not in {"web.search", "web.fetch"}:
        return None
    for step in reversed(attempts):
        if step.get("capability") != "web.search":
            continue
        action = step["action"]
        contract = action.get("execution_contract", {})
        receipt = action.get("host_execution_receipt", {})
        observed = receipt.get("execution_observation", {}).get("observation_id")
        result = receipt.get("result", {})
        params = contract.get("effective_parameters", {})
        if (contract.get("allowed") is True and observed and observed == step.get("execution_observation_id")
                and result.get("tool") == "web_search" and result.get("data", {}).get("http_attempted") is True
                and params.get("allow_fallback") is False):
            observed_provider = result["data"].get("actual_provider")
            provider = params.get("provider") or observed_provider
            if provider in SUPPORTED_SEARCH_PROVIDERS and observed_provider in (None, provider):
                return provider
    return None

def web_route(text, previous_run=None, *, terminal_web=False, session_web=None):
    # A separate /web line can authorize a single following terminal input.
    control = "/web "+text if terminal_web and command_body(text) is None else text
    continue_search = bool(RESUME_SEARCH.fullmatch(text.strip()))
    previous_provider = prior_public_search(previous_run) if continue_search and not (session_web or terminal_web) else None
    resume = continue_search and bool(session_web or terminal_web or previous_provider)
    names = frozenset(permitted_tools(control, session_web=bool(session_web), resumed_search=resume))
    provider, excluded = provider_scope(control)
    if previous_provider:
        names = names & {"web_search"}
        provider = previous_provider
    bare = command_body(text) == ""
    release = RELEASE.fullmatch(text.strip()) if names else None
    if bare or (release and GRANT_CLAUSE.fullmatch(release["grant"].strip())):
        previous = unattempted_search(previous_run)
        if previous and (bare or ("web_search" in names and explicit_provider(previous)==explicit_provider(text))):
            # Carry forward restrictions on the previous request, never broaden it.
            continued = frozenset(permitted_tools(previous))
            previous_provider, previous_exclusions = provider_scope(previous)
            return WebRoute(continued if bare else names & continued, previous_provider,
                            "web_search", "resume_unattempted_search", previous, excluded | previous_exclusions)
        if bare:
            return WebRoute(frozenset(),basis="await_topic")
    fetch_targets = explicit_fetch_targets(control) if "web_fetch" in names else None
    if fetch_targets == ():
        names = names - {"web_fetch", "web_search"}
    first = requested_first_tool(control,names)
    if "web_search" in names and (resume or DIRECT_WEB.match(QUOTED.sub(" ",text.strip()))):
        first = "web_search"
    basis = "explicit_web_action" if first else "auto"
    if resume and first:
        basis = "continue_public_search"
    plain = QUOTED.sub(" ",text.strip())
    if (session_web and "web_search" in names and NEW_RESEARCH.search(plain)
            and not OPTIONAL_SEARCH.search(plain)):
        first, basis = "web_search", "session_new_research"
    if first == "web_search" and (provider in excluded or excluded >= SUPPORTED_SEARCH_PROVIDERS):
        first, basis = None, "auto"
    if fetch_targets == ():
        basis = "ambiguous_fetch_target"
    return WebRoute(names, provider if "web_search" in names else None, first, basis,
                    excluded_providers=excluded, fetch_targets=fetch_targets)



class DailyToolRegistry(ToolRegistry):
    def __init__(self, *args, fetch_targets=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.fetch_targets = fetch_targets

    def execute(self, tool_name, arguments, objective):
        # This is before WebFetchCapability chooses network or saved-snapshot reads.
        if tool_name == "web_fetch" and self.fetch_targets is not None and arguments.get("url") not in self.fetch_targets:
            from harness.observation_boundary import CapabilityInputError
            raise CapabilityInputError("Fetch URL is outside the current input's allowed destination; no request made")
        return super().execute(tool_name, arguments, objective)


def scoped_web_bindings(bindings, route):
    for binding in bindings:
        if binding.tool_name not in route.names:
            continue
        if binding.tool_name == "web_fetch" and route.fetch_targets is not None:
            schema = deepcopy(binding.input_schema)
            schema["properties"]["url"]["enum"] = list(route.fetch_targets)
            binding = replace(binding, input_schema=schema)
        yield binding


class TurnReadOnlyHost(SharedExecutionHost):
    def authority_reference(self, workflow_id, input_id):
        # A resumed workflow can have both offline and network-authorized inputs.
        return f"system:daily-read-only-v1:{workflow_id}:{input_id}"


def public_address(host):
    if not host or "." not in host and ":" not in host or "%" in host:
        raise URLError("public DNS name or address required")
    addresses = list(dict.fromkeys(x[4][0] for x in socket.getaddrinfo(
        host, 443, type=socket.SOCK_STREAM)))
    if not addresses or any(not ipaddress.ip_address(ip).is_global or
                            ipaddress.ip_address(ip).is_multicast for ip in addresses):
        raise URLError("destination outside public network")
    return next((ip for ip in addresses if ":" not in ip), addresses[0])


class PublicTLS(http.client.HTTPSConnection):
    def connect(self):
        # CONNECT and direct sockets both use the checked address. TLS still
        # authenticates the original hostname. The local proxy is operator-owned.
        host = self._tunnel_host or self.host
        address = public_address(host)
        if self._tunnel_host:
            self._tunnel_host = address
        else:
            self.host = address
        try:
            http.client.HTTPConnection.connect(self)
            self.sock = self._context.wrap_socket(self.sock, server_hostname=host)
        finally:
            if not self._tunnel_host:
                self.host = host


class PublicTLSHandler(HTTPSHandler):
    def https_open(self, req):
        return self.do_open(PublicTLS, req, context=self._context)


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class DailyWebAdapter(WebAdapter):
    def __init__(self, *, provider=None, excluded_providers=(), **kwargs):
        super().__init__(**kwargs)
        self.required_provider = provider
        self.excluded_providers = frozenset(excluded_providers)

    def search(self, connection, query, *, max_results=5, constraints=None):
        from harness.observation_boundary import CapabilityInputError
        provider = getattr(constraints, "provider", "")
        if self.required_provider and provider != self.required_provider:
            raise CapabilityInputError(f"This input specifies provider={self.required_provider}; no query sent")
        if self.excluded_providers and (not provider or provider in self.excluded_providers):
            raise CapabilityInputError("An explicitly permitted search provider is required; no query sent")
        if getattr(constraints, "allow_fallback", True) is not False:
            raise CapabilityInputError("Daily does not authorize provider fallback; no query sent")
        return super().search(connection, query, max_results=max_results, constraints=constraints)

    def open_request(self, request, *, timeout):
        url = urlsplit(request.full_url)
        if (url.scheme != "https" or not url.hostname or url.port not in (None, 443)
                or url.username is not None or url.password is not None):
            raise URLError("daily accepts public HTTPS pages on port 443")
        return build_opener(PublicTLSHandler(), NoRedirect()).open(request, timeout=timeout)


def stage_resume_catalogue(out, thread, specs, dump):
    """0.170 resumes the catalogue from SessionMeta. Adapt only the verified working copy."""
    proof = json.loads((out / "native-copy-proof.json").read_text())
    original = Path(proof["rollout_original"]).resolve(strict=True)
    work = Path(proof["rollout_copy"]).resolve(strict=True)
    if (not work.is_relative_to((out / "codex-home/sessions").resolve()) or
            original.is_relative_to(out) or os.path.samefile(work, original) or
            proof["thread_id"] != thread):
        raise ValueError("Invalid working rollout identity")
    with work.open("rb") as stream:
        if hashlib.file_digest(stream, "sha256").hexdigest() != proof["rollout_sha256"]:
            raise ValueError("Working rollout differs from verified copy")
        stream.seek(0)
        first = stream.readline()
        meta = json.loads(first)
        if meta.get("type") != "session_meta" or meta["payload"].get("id") != thread:
            raise ValueError("Unknown Native catalogue format")
        saved = meta["payload"]["dynamic_tools"]
        keep = lambda tools: [tool for tool in tools if tool["name"] not in WEB_NAMES]
        if keep(saved) != keep(specs):
            raise ValueError("Unexpected change to non-web Native tools")
        if saved == specs:
            return
        if proof["dynamic_tools_SQLite_rows"]:
            raise ValueError("Conflicting Native tool store requires review")
        meta["payload"]["dynamic_tools"] = specs
        with tempfile.NamedTemporaryFile(dir=work.parent, delete=False) as tmp:
            temp = Path(tmp.name)
            try:
                tmp.write((json.dumps(meta, ensure_ascii=False, separators=(",", ":"))+"\n").encode())
                remainder = hashlib.sha256()
                for line in stream:
                    if json.loads(line).get("type") == "session_meta":
                        raise ValueError("Ambiguous Native session metadata")
                    tmp.write(line)
                    remainder.update(line)
                tmp.flush()
                os.fsync(tmp.fileno())
                os.replace(temp, work)
            finally:
                temp.unlink(missing_ok=True)
    dump(out / "web-resume-catalogue.json", {
        "thread": thread, "sealed_source_sha256": proof["rollout_sha256"],
        "unchanged_event_tail_sha256": remainder.hexdigest(),
        "old": [s["name"] for s in saved], "new": [s["name"] for s in specs],
        "scope": "working SessionMeta dynamic_tools only; sealed source retained"})


def bind_search_scope(request, provider, authority_block=None, *, excluded_providers=()):
    """Constrain proposals to the intersection of current Host and daily provider policy."""
    search = next((t for t in request["tools"] if t.get("name") == "web_search"), None)
    if search is None:
        return
    # turn_context_payload has separated authority-checked bindings from
    # untrusted interpretations. Read only the current Host application block.
    constraints = []
    if authority_block and authority_block.get("kind") == "application":
        facts = json.loads(authority_block["value"])
        constraints = facts["constraints"]
    schema = search["parameters"]
    properties = schema["properties"]
    supported = properties["provider"]["enum"]
    required = {value.split("=", 1)[1] for value in constraints if value.startswith("web.provider=")}
    excluded = {value.split("=", 1)[1] for value in constraints if value.startswith("web.exclude_provider=")}
    excluded.update(excluded_providers)
    if provider:
        required.add(provider)
    eligible = [name for name in supported if name not in excluded and (not required or required == {name})]
    if not eligible:
        request["tools"].remove(search)
        return
    search["strict"] = True
    properties["provider"]["enum"] = eligible
    # SharedExecutionHost supplies false and issues no provider_switch grant.
    # Even when no provider is named on THIS line, true cannot execute here.
    if properties["allow_fallback"]["type"] != "boolean":
        raise ValueError("Unexpected web search fallback protocol")
    properties["allow_fallback"].update(enum=[False], description="Use false. This daily Host only executes a same-provider search.")
    if required or excluded:
        schema["required"] = list(dict.fromkeys([*schema["required"], "provider", "allow_fallback"]))


def current_web_notice(request, specs, *, resumed=False, provider=None, authority_block=None, received_at=None, excluded_providers=()):
    """Render the operations permitted for this input, after ordinary historical material."""
    check_wire(request, specs)
    bind_search_scope(request, provider, authority_block, excluded_providers=excluded_providers)
    names = sorted(t["name"] for t in request["tools"] if t.get("name") in WEB_NAMES)
    unavailable = any(s["name"] == "web_search" for s in specs) and "web_search" not in names
    clock = ""
    if received_at is not None:
        from datetime import datetime
        when = datetime.fromisoformat(received_at)
        if when.utcoffset() is None:
            raise ValueError("Daily input timestamp requires a UTC offset")
        clock = ("本轮用户输入的本地日期 " + when.date().isoformat() + "（UTC" + when.strftime("%z") + "）。"
                 "当前或最近的数值，需要可见资料把对象、指标和数据日期对应起来。"
                 "网页取得日期只说明何时访问；无法对应时标明尚未核实。")
    if not names and not unavailable:
        request["input"].append({"type":"message","role":"developer","content":[{"type":"input_text","text":
            clock + "UAEA Host 本轮处于离线模式，本轮没有网页查询或取页工具。历史网页调用只属于原轮。"
            "用已有材料回答；需要新资料时说明尚缺什么。用户可用 /web 加查询内容，或 /web on 开启连续研究。"}]})
        return
    notice = (clock + "UAEA Host 本轮联网状态（仅当前用户请求）：已开放 " + ("、".join(names) or "零项网页工具") +
              "。历史中的不可用回执只描述原调用；当前原生 Shell 的网络限制只适用于 Shell。"
              "如果用户要求查询网上的资料，请使用本轮开放的相应工具，按本次回执报告执行与取证结果。"
              "用户只是允许按需联网时，由你判断是否需要查询。")
    if unavailable:
        notice += "当前约束没有共同允许的搜索服务商，本次无法发起搜索。"
    if resumed:
        notice += "本轮单独授权继续上一条尚未发起的明确查询，查询主题和语言以原用户消息为准。"
    request["input"].append({"type":"message","role":"developer","content":[{"type":"input_text","text":notice}]})


def web_activity(names, calls, *, thread=None, turn=None):
    exposed = sorted(WEB_NAMES.intersection(names))
    if not exposed:
        return ""
    actual = [c for c in calls if c.get("tool") in WEB_NAMES]
    counts = [f"{name} {sum(c.get('tool') == name for c in actual)} 次" for name in exposed]
    message = "[UAEA Host] 本轮开放 " + "、".join(exposed) + "。实际工具调用：" + "，".join(counts) + "。"
    if not actual:
        return message + "本轮没有新的 Host 网页工具回执。"
    succeeded = sum(call.get("success") is True for call in actual)
    message += f"成功回执 {succeeded}/{len(actual)}。"
    facts = []
    for call in actual:
        for part in call.get("contentItems", []):
            try:
                receipt = json.loads(part["text"])
            except (KeyError, ValueError, TypeError):
                continue
            if not isinstance(receipt, dict):
                continue
            identity, data = receipt.get("identity"), receipt.get("data")
            if not (call.get("id") and isinstance(identity, dict) and identity.get("call_id") == call["id"]
                    and isinstance(data, dict)):
                continue
            if thread is not None and identity.get("thread_id") != thread:
                continue
            if turn is not None and identity.get("turn_id") != turn:
                continue
            detail = None
            if call.get("success") is False:
                status = data.get("http_status")
                if data.get("http_attempted") is True and type(status) is int and 300 <= status < 400 and call["tool"] == "web_fetch":
                    detail = f"取页收到 HTTP {status} 重定向；本次没有跟随跳转，未取得目标正文。"
                elif data.get("failure_scope") == "web.provider_fallback":
                    detail = "Host 拒绝的是切换搜索服务商；同服务商查询仍按本轮权限校验。"
                elif data.get("http_attempted") is True and type(status) is int and 400 <= status <= 599:
                    detail = f"{call['tool']} 收到 HTTP {status}，该次未取得所需资料。"
                elif data.get("execution_status") == "validation_failed":
                    detail = "Host 校验未通过，该次未执行网页操作。"
                elif data.get("http_attempted") is True:
                    detail = "该次已尝试联网，未取得所需资料。"
            elif call.get("success") is True and receipt.get("ok") is True:
                if call["tool"] == "web_search" and data.get("access_event_id"):
                    detail = "搜索取得的是结果列表，数据日期仍需核验。"
                if call["tool"] == "web_fetch" and isinstance(data.get("source_excerpt"), dict):
                    excerpt = data["source_excerpt"]
                    if isinstance(excerpt.get("text"), str) and excerpt.get("scope") == "extracted_snapshot_segment_not_full_page":
                        detail = f"该次取页的可见正文为 {len(excerpt['text'])} 字符。"
            if detail and detail not in facts:
                facts.append(detail)
    return message + " " + " ".join(facts) if facts else message


def native_wire_schema(node):
    # 0.170's provider serializer omits numeric/string/array bounds. Types,
    # required fields, enums and descriptions must still match the Host protocol.
    if isinstance(node, dict):
        return {k: native_wire_schema(v) for k,v in node.items()
                if k not in {"minimum", "maximum", "maxLength", "maxItems"}}
    if isinstance(node, list):
        return [native_wire_schema(x) for x in node]
    return node


def check_wire(request, specs):
    wanted = {s["name"]: s for s in specs if s["name"] in WEB_NAMES}
    found = [s for s in request.get("tools", []) if s.get("name") in WEB_NAMES]
    if len(found) != len(wanted) or {s["name"] for s in found} != wanted.keys():
        raise ValueError("Daily web capability mismatch on outgoing request")
    for tool in found:
        native = wanted[tool["name"]]
        if (tool.get("parameters") not in (native["inputSchema"], native_wire_schema(native["inputSchema"])) or
                tool.get("description") != native["description"]):
            raise ValueError("Daily web schema mismatch on outgoing request")
