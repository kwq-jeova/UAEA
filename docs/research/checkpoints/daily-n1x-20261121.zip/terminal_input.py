"""Validate the operator's exact text before admitting a research turn."""
from contextlib import contextmanager
import sys
import termios


def validate_input_text(text):
    # Linux stdin may expose undecodable bytes as surrogate escapes.
    # Never substitute guessed characters into a user quote.
    text.encode("utf-8", errors="strict")


@contextmanager
def utf8_terminal_erase(stream):
    """Let a canonical Linux tty erase one complete UTF-8 character on Backspace."""
    if not sys.platform.startswith("linux") or not stream.isatty():
        yield
        return
    fd = stream.fileno()
    attrs = termios.tcgetattr(fd)
    # IUTF8 is part of the Linux termios ABI, sometimes omitted by Python.
    flag = getattr(termios, "IUTF8", 0x4000)
    changed = not (attrs[0] & flag)
    if changed:
        attrs[0] |= flag
        termios.tcsetattr(fd, termios.TCSANOW, attrs)
    try:
        yield
    finally:
        if changed:
            attrs = termios.tcgetattr(fd)
            attrs[0] &= ~flag
            termios.tcsetattr(fd, termios.TCSANOW, attrs)


def line_reader():
    """Use a screen-column-aware editor on interactive consoles only."""
    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        return input

    from pathlib import Path
    # Local Ubuntu packages for this entry only; no installation at startup.
    sys.path.insert(0, str(Path(__file__).resolve().with_name("terminal_vendor")))
    try:
        from prompt_toolkit import PromptSession
        from prompt_toolkit.history import DummyHistory
        from prompt_toolkit.output.vt100 import Vt100_Output
    finally:
        sys.path.pop(0)
    output = Vt100_Output.from_pty(sys.stdout)
    output.enable_cpr = False
    editor = PromptSession(history=DummyHistory(), output=output)
    return editor.prompt
