import json
import unittest
import study  # Load the same Harness dependencies as the Daily entry.
from daily_web import current_web_notice,web_activity

class DailyDeliveryTests(unittest.TestCase):
    def test_current_turn_date_follows_history(self):
        q={"tools":[],"input":[{"role":"user","content":"旧窗口2024年"}]}
        current_web_notice(q,[],received_at="2026-11-21T00:02:00+08:00")
        self.assertEqual(q["input"][0]["content"],"旧窗口2024年")
        self.assertIn("2026-11-21",q["input"][-1]["content"][0]["text"])
        with self.assertRaises(ValueError):
            current_web_notice(q,[],received_at="2026-11-21T00:02:00")

    def test_only_real_current_http_reply_can_name_status(self):
        call={"tool":"web_fetch","id":"f","success":False,"contentItems":[{"text":json.dumps({
              "identity":{"call_id":"f","thread_id":"s","turn_id":"t"},
              "data":{"http_attempted":True,"http_status":404}})}]}
        self.assertIn("HTTP 404",web_activity(["web_fetch"],[call],thread="s",turn="t"))
        self.assertNotIn("HTTP 404",web_activity(["web_fetch"],[call],thread="s",turn="other"))
        self.assertNotIn("HTTP 404",web_activity(["web_fetch"],[call],thread="other",turn="t"))
