"""A turn-local inventory of Host receipts also visible in this outgoing request."""
import hashlib
import json
import threading
from collections import Counter
from dataclasses import dataclass

_HISTORY = "Historical runtime observation, not a tool invocation or user authorization:\n"
_WEB = frozenset(("web_search", "web_fetch"))


def _digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                    separators=(",", ":")).encode()).hexdigest()


@dataclass(frozen=True)
class _Receipt:
    tool: str
    reply_hash: str
    kind: str
    reason: str
    execution_status: str
    http_status: object


def _shape(tool, reply, data):
    if reply.get("ok") is False:
        return "failed"
    if reply.get("ok") is not True:
        return "other"
    if tool == "web_search":
        rows=data.get("citable_results")
        if isinstance(rows,list) and any(isinstance(r, dict) and r.get("citation_scope")=="search_result_only" and r.get("snippet")
               for r in rows):
            return "snippets"
    elif tool == "web_fetch":
        e = data.get("source_excerpt")
        if isinstance(e,dict) and e.get("scope")=="extracted_snapshot_segment_not_full_page" and isinstance(e.get("text"),str) and e["text"]:
            if hashlib.sha256(e["text"].encode()).hexdigest()==e.get("text_sha256"):
                return "excerpts"
    return "other"


class WebEvidenceBasis:
    def __init__(self):
        self._receipts={}
        self._lock=threading.Lock()

    def observe(self, params, result):
        tool=params.get("tool")
        cid=params.get("callId")
        if tool not in _WEB or not cid:
            return
        try:
            reply=json.loads(result["contentItems"][0]["text"])
        except (ValueError,TypeError,KeyError,IndexError):
            return
        if not isinstance(reply,dict) or reply.get("tool")!=tool or type(result.get("success")) is not bool or result["success"] is not reply.get("ok"):
            return
        identity=reply.get("identity") or {}
        if not isinstance(identity,dict) or not all(params.get(k) and params[k]==identity.get(v) for k,v in (
            ("threadId","thread_id"),("turnId","turn_id"),("callId","call_id")
        )):
            return
        data=reply.get("data")
        if not isinstance(data,dict):
            return
        rec=_Receipt(tool,_digest(reply),_shape(tool,reply,data),data.get("reason"),
                     data.get("execution_status"),data.get("http_status"))
        with self._lock:
            if cid in self._receipts and self._receipts[cid]!=rec:
                self._receipts[cid]=None  # conflicting or reused identity cannot corroborate a projection
            else:
                self._receipts[cid]=rec

    def project(self, request, proposed):
        with self._lock:
            eligible={c:r for c,r in self._receipts.items() if r and proposed.get(c)==r.tool}
        if not eligible:
            return None
        seen={}
        for item in request.get("input",[]):
            if not isinstance(item,dict):
                continue
            cid=item.get("call_id")
            if item.get("type")=="function_call_output" and cid in eligible:
                try: value=json.loads(item["output"])
                except (TypeError,ValueError,KeyError): continue
                if _digest(value)==eligible[cid].reply_hash:
                    seen[cid]=eligible[cid].kind
            elif item.get("role") in ("developer","user") and isinstance(item.get("content"),list):
                for part in item["content"]:
                    text=part.get("text","") if isinstance(part,dict) else ""
                    if not isinstance(text,str) or not text.startswith(_HISTORY):
                        continue
                    for line in text[len(_HISTORY):].splitlines():
                        try: fact=json.loads(line)
                        except ValueError: continue
                        if not isinstance(fact,dict):
                            continue
                        cid=fact.get("call_id"); r=eligible.get(cid)
                        obs=fact.get("observation")
                        if (r and r.kind=="failed" and fact.get("schema")=="uaea.terminal_attempt_fact.v1"
                            and fact.get("source")=="runtime_history_projection" and fact.get("terminal") is True
                            and fact.get("replayable") is False and fact.get("state") in ("FAILED","REJECTED")
                            and fact.get("tool")==r.tool and fact.get("reason")==r.reason
                            and isinstance(obs,dict) and obs.get("execution_succeeded") is False
                            and obs.get("execution_status")==r.execution_status and obs.get("http_status")==r.http_status):
                            seen[cid]="failed"
        if not seen:
            return None
        c=Counter(seen.values())
        text=(f"本轮已执行且在本请求内可核对的网页回执：搜索摘要 {c['snippets']} 次，含正文片段的取页 {c['excerpts']} 次，"
              f"失败 {c['failed']} 次，其他 {c['other']} 次。只计算本轮实际可见的回执。"
              "成功打开页面只说明取得该段文字；其中提到的另一个来源可能只有摘要。按可见原文逐项回答，"
              "把每项的对象、数值、单位和适用时间对应到同一记录。访问日只说明何时访问。"
              "材料不足的项保留未核实，已有依据的项可以直接交付。")
        request["input"].append({"type":"message","role":"developer","content":[{"type":"input_text","text":text}]})
        return dict(seen)
