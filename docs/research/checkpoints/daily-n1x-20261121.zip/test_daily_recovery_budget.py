"""CPU regression for authorized tool loops and the interrupted daily recovery gate."""
import json
import unittest
from copy import deepcopy

from entry_helpers import verify_request_limit
from web_repeat_budget import RepeatedWebFailure
from budget_policy import BudgetConfig, BudgetPolicy


def failed_call(cid, *, args=None, tool="web_search", thread="t", turn="n", status="validation_failed",
                **extra):
    params = dict(tool=tool, threadId=thread, turnId=turn, callId=cid,
                  arguments={"query": "Q", "allow_fallback": True} if args is None else args)
    data = dict(execution_succeeded=False, execution_status=status, **extra)
    receipt = dict(ok=False, tool=tool, status=status, data=data,
                   identity=dict(call_id=cid, thread_id=thread, turn_id=turn))
    return params, dict(success=False, contentItems=[dict(type="inputText", text=json.dumps(receipt))])


class RepeatedFailureTests(unittest.TestCase):
    def setUp(self):
        self.tracker = RepeatedWebFailure()
        self.fallback = dict(failure_stage="contract_validation", reason="authorization_unknown",
                             failure_scope="web.provider_fallback", effective_state_id="state-A")

    def add(self, cid, *, request_id=None, **kw):
        self.tracker.proposed(request_id or ("request-" + cid), cid, kw.get("tool","web_search"))
        self.tracker.observe(*failed_call(cid, **kw))

    def project(self, *, last=False, tools=("web_search", "web_fetch")):
        q = dict(input=[], tools=[{"name": t} for t in tools], tool_choice="auto")
        self.event = self.tracker.project(q, last_request=last)
        return q

    def test_repeat_allows_fix_then_bounds_exact_same_failure(self):
        self.add("a", **self.fallback)
        self.assertFalse(self.project()["input"])
        self.add("b", args={"allow_fallback": True, "query": "Q"}, **self.fallback)
        self.assertEqual(self.project()["tool_choice"], "auto")
        self.assertEqual(self.event["failure_kind"], "contract_validation")
        self.add("c", **self.fallback)
        self.assertEqual(self.project()["tool_choice"], "none")
        self.assertEqual(self.event["call_ids"], ["a", "b", "c"])

    def test_only_repeated_failure_reserves_last_slot(self):
        self.add("a", **self.fallback)
        self.assertEqual(self.project(last=True)["tool_choice"], "auto")
        self.add("b", **self.fallback)
        self.assertEqual(self.project(last=True)["tool_choice"], "none")
        self.assertFalse(self.project(last=True, tools=("read_section",))["input"])

    def test_parallel_calls_in_one_provider_response_are_one_opportunity_to_retry(self):
        for cid in ("a", "b", "c"):
            self.add(cid, request_id="one-response", **self.fallback)
        self.assertFalse(self.project(last=True)["input"])
        self.add("d", request_id="first-retry", **self.fallback)
        self.assertEqual(self.project()["tool_choice"], "auto")
        self.assertEqual(self.event["provider_request_ids"], ["one-response", "first-retry"])
        self.add("e", request_id="second-retry", **self.fallback)
        self.assertEqual(self.project()["tool_choice"], "none")

    def test_new_arguments_success_other_tool_and_authority_reset(self):
        for change in ("query", "success", "another_tool", "state", "turn", "reason"):
            with self.subTest(change=change):
                self.setUp()
                self.add("a", **self.fallback)
                if change == "success":
                    self.tracker.observe(dict(tool="web_search", callId="b"), dict(success=True))
                elif change == "another_tool":
                    self.tracker.observe(dict(tool="read_section", callId="b"), dict(success=False))
                else:
                    variants = {"query": dict(args={"query": "q", "allow_fallback": False}),
                                "state": dict(effective_state_id="state-B"), "turn": dict(turn="next"),
                                "reason": dict(reason="authorization_denied")}
                    self.add("b", **(self.fallback | variants[change]))
                self.add("c", **self.fallback)
                self.assertFalse(self.project(last=True)["input"])

    def test_http_failure_and_timeout_keep_own_scope_and_one_retry(self):
        url = {"url": "https://example.test/one"}
        for status, extra in (("http_failure", dict(http_status=302, reason="http_error")),
                              ("http_failure", dict(http_status=403, reason="http_error")),
                              ("network_failure", dict(transport_failure={"error_kind": "timeout"},
                                                       reason="connection_failed"))):
            with self.subTest(status=status):
                self.tracker = RepeatedWebFailure()
                opts = dict(tool="web_fetch", status=status, http_attempted=True, **extra)
                self.add("a", args=url, **opts)
                self.assertFalse(self.project()["input"])
                self.add("b", args=url, **opts)
                self.assertEqual(self.project()["tool_choice"], "auto")
                self.assertEqual(self.event["failure_kind"], status)
                self.add("c", args={"url": "https://example.test/two"}, **opts)
                self.assertFalse(self.project(last=True)["input"])
                self.add("d", args={"url": "https://example.test/two"}, **opts)
                changed = (dict(http_status=403 if extra.get("http_status")==302 else 429)
                           if status=="http_failure" else dict(transport_failure={"error_kind":"dns"}))
                self.add("e", args={"url": "https://example.test/two"}, **(opts | changed))
                self.assertFalse(self.project(last=True)["input"])

    def test_unbound_unknown_duplicate_or_historical_receipts_do_not_count(self):
        self.add("a", **self.fallback)
        self.add("a", **self.fallback)
        self.assertFalse(self.project(last=True)["input"])
        wrong, result = failed_call("b", **self.fallback)
        self.tracker.observe(wrong | {"turnId": "different"}, result)
        self.add("c", **self.fallback)
        self.assertFalse(self.project(last=True)["input"])
        self.add("d", status="failed")
        self.add("e", status="failed")
        self.assertFalse(self.project(last=True)["input"])
        q = dict(input=[dict(type="function_call_output", output=result["contentItems"][0]["text"])],
                 tools=[{"name":"web_search"}], tool_choice="auto")
        self.assertIsNone(RepeatedWebFailure().project(q,last_request=True))

    def test_parameter_failure_does_not_claim_network_attempt(self):
        opts = dict(failure_stage="capability_input", validation_source="capability_input",
                    http_attempted=False, reason="invalid_arguments")
        for cid in ("a", "b"):
            self.add(cid, **opts)
        self.assertEqual(self.project()["tool_choice"], "auto")
        self.assertEqual(self.event["failure_kind"], "capability_input")
        self.add("c", **(opts | {"http_attempted": True}))
        self.assertFalse(self.project(last=True)["input"])


class RecoveryBudgetTests(unittest.TestCase):
    def setUp(self):
        policy = BudgetPolicy(BudgetConfig(60, 600, 300, 2))
        self.rows = [dict(event="request_admission", attempt=i,
                          decision=policy.begin_request(f"provider-{i}").to_dict()) for i in (1, 2, 3, 4)]
        self.budget = policy.snapshot()
        self.http = [dict(event="request_prepared", request_id=x) for x in ("wire-a", "wire-b")]

    def test_multiple_denied_projections_are_not_requests(self):
        verify_request_limit(self.budget, self.rows, self.http)

    def test_bridge_preserves_hard_and_inactivity_stop_reasons(self):
        from study import budget_stop_reason
        self.assertEqual(budget_stop_reason(self.budget["terminal"]), "REQUEST_BUDGET_NO_RETRY")
        for reason in ("hard_time_limit", "no_progress_limit"):
            self.assertEqual(budget_stop_reason({"reason": reason}), reason)

    def test_missing_extra_reused_outgoing_and_missing_refusal(self):
        for http in (self.http[:1], self.http + [self.http[0]], [self.http[0], self.http[0]]):
            with self.assertRaises(ValueError):
                verify_request_limit(self.budget, self.rows, http)
        with self.assertRaises(ValueError):
            verify_request_limit(self.budget, self.rows[:2], self.http)

    def test_relabelled_admissions_and_counters_are_refused(self):
        for i, change in ((0, {"request_count": 2}), (2, {"reason": "hard_time_limit"}),
                          (3, {"request_allowed": True})):
            rows = deepcopy(self.rows)
            rows[i]["decision"].update(change)
            with self.assertRaises(ValueError):
                verify_request_limit(self.budget, rows, self.http)
        self.budget["config"]["max_requests"] = 9
        with self.assertRaises(ValueError):
            verify_request_limit(self.budget, self.rows, self.http)


if __name__ == "__main__":
    unittest.main()
